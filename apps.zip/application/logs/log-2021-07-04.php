<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-04 05:50:02 --> Config Class Initialized
INFO - 2021-07-04 05:50:02 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:50:02 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:50:02 --> Utf8 Class Initialized
INFO - 2021-07-04 05:50:02 --> URI Class Initialized
INFO - 2021-07-04 05:50:02 --> Router Class Initialized
INFO - 2021-07-04 05:50:02 --> Output Class Initialized
INFO - 2021-07-04 05:50:02 --> Security Class Initialized
DEBUG - 2021-07-04 05:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:50:02 --> Input Class Initialized
INFO - 2021-07-04 05:50:02 --> Language Class Initialized
ERROR - 2021-07-04 05:50:02 --> 404 Page Not Found: /index
INFO - 2021-07-04 05:50:28 --> Config Class Initialized
INFO - 2021-07-04 05:50:28 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:50:28 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:50:28 --> Utf8 Class Initialized
INFO - 2021-07-04 05:50:28 --> URI Class Initialized
INFO - 2021-07-04 05:50:28 --> Router Class Initialized
INFO - 2021-07-04 05:50:28 --> Output Class Initialized
INFO - 2021-07-04 05:50:28 --> Security Class Initialized
DEBUG - 2021-07-04 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:50:28 --> Input Class Initialized
INFO - 2021-07-04 05:50:28 --> Language Class Initialized
INFO - 2021-07-04 05:50:28 --> Language Class Initialized
INFO - 2021-07-04 05:50:28 --> Config Class Initialized
INFO - 2021-07-04 05:50:28 --> Loader Class Initialized
INFO - 2021-07-04 05:50:28 --> Helper loaded: url_helper
INFO - 2021-07-04 05:50:28 --> Helper loaded: file_helper
INFO - 2021-07-04 05:50:28 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:50:28 --> Database Driver Class Initialized
INFO - 2021-07-04 05:50:28 --> Email Class Initialized
INFO - 2021-07-04 05:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:50:28 --> Controller Class Initialized
DEBUG - 2021-07-04 05:50:28 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 05:50:28 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 05:50:28 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 05:50:28 --> Final output sent to browser
DEBUG - 2021-07-04 05:50:28 --> Total execution time: 0.0856
INFO - 2021-07-04 05:50:29 --> Config Class Initialized
INFO - 2021-07-04 05:50:29 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:50:29 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:50:29 --> Utf8 Class Initialized
INFO - 2021-07-04 05:50:29 --> URI Class Initialized
INFO - 2021-07-04 05:50:29 --> Router Class Initialized
INFO - 2021-07-04 05:50:29 --> Output Class Initialized
INFO - 2021-07-04 05:50:29 --> Config Class Initialized
INFO - 2021-07-04 05:50:29 --> Security Class Initialized
INFO - 2021-07-04 05:50:29 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:50:29 --> Input Class Initialized
DEBUG - 2021-07-04 05:50:29 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:50:29 --> Language Class Initialized
INFO - 2021-07-04 05:50:29 --> Utf8 Class Initialized
INFO - 2021-07-04 05:50:29 --> URI Class Initialized
INFO - 2021-07-04 05:50:29 --> Router Class Initialized
INFO - 2021-07-04 05:50:29 --> Language Class Initialized
INFO - 2021-07-04 05:50:29 --> Config Class Initialized
INFO - 2021-07-04 05:50:29 --> Loader Class Initialized
INFO - 2021-07-04 05:50:29 --> Output Class Initialized
INFO - 2021-07-04 05:50:29 --> Helper loaded: url_helper
INFO - 2021-07-04 05:50:29 --> Security Class Initialized
INFO - 2021-07-04 05:50:29 --> Helper loaded: file_helper
INFO - 2021-07-04 05:50:29 --> Helper loaded: develop_helper
DEBUG - 2021-07-04 05:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:50:29 --> Input Class Initialized
INFO - 2021-07-04 05:50:29 --> Language Class Initialized
INFO - 2021-07-04 05:50:29 --> Database Driver Class Initialized
INFO - 2021-07-04 05:50:29 --> Language Class Initialized
INFO - 2021-07-04 05:50:29 --> Config Class Initialized
INFO - 2021-07-04 05:50:29 --> Loader Class Initialized
INFO - 2021-07-04 05:50:29 --> Helper loaded: url_helper
INFO - 2021-07-04 05:50:29 --> Email Class Initialized
INFO - 2021-07-04 05:50:29 --> Helper loaded: file_helper
INFO - 2021-07-04 05:50:29 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:50:29 --> Controller Class Initialized
DEBUG - 2021-07-04 05:50:29 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 05:50:29 --> Database Driver Class Initialized
INFO - 2021-07-04 05:50:29 --> Final output sent to browser
DEBUG - 2021-07-04 05:50:29 --> Total execution time: 0.1087
INFO - 2021-07-04 05:50:29 --> Email Class Initialized
INFO - 2021-07-04 05:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:50:29 --> Controller Class Initialized
DEBUG - 2021-07-04 05:50:29 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 05:50:29 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 05:50:29 --> Final output sent to browser
DEBUG - 2021-07-04 05:50:29 --> Total execution time: 0.1127
INFO - 2021-07-04 05:50:29 --> Config Class Initialized
INFO - 2021-07-04 05:50:29 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:50:29 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:50:29 --> Utf8 Class Initialized
INFO - 2021-07-04 05:50:29 --> URI Class Initialized
INFO - 2021-07-04 05:50:29 --> Router Class Initialized
INFO - 2021-07-04 05:50:29 --> Output Class Initialized
INFO - 2021-07-04 05:50:29 --> Security Class Initialized
DEBUG - 2021-07-04 05:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:50:29 --> Input Class Initialized
INFO - 2021-07-04 05:50:29 --> Language Class Initialized
INFO - 2021-07-04 05:50:29 --> Language Class Initialized
INFO - 2021-07-04 05:50:29 --> Config Class Initialized
INFO - 2021-07-04 05:50:29 --> Loader Class Initialized
INFO - 2021-07-04 05:50:29 --> Helper loaded: url_helper
INFO - 2021-07-04 05:50:29 --> Helper loaded: file_helper
INFO - 2021-07-04 05:50:29 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:50:29 --> Database Driver Class Initialized
INFO - 2021-07-04 05:50:29 --> Email Class Initialized
INFO - 2021-07-04 05:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:50:29 --> Controller Class Initialized
DEBUG - 2021-07-04 05:50:29 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 05:50:29 --> Final output sent to browser
DEBUG - 2021-07-04 05:50:29 --> Total execution time: 0.1207
INFO - 2021-07-04 05:51:17 --> Config Class Initialized
INFO - 2021-07-04 05:51:17 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:51:17 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:51:17 --> Utf8 Class Initialized
INFO - 2021-07-04 05:51:17 --> URI Class Initialized
INFO - 2021-07-04 05:51:17 --> Router Class Initialized
INFO - 2021-07-04 05:51:17 --> Output Class Initialized
INFO - 2021-07-04 05:51:17 --> Security Class Initialized
DEBUG - 2021-07-04 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:51:17 --> Input Class Initialized
INFO - 2021-07-04 05:51:17 --> Language Class Initialized
INFO - 2021-07-04 05:51:17 --> Language Class Initialized
INFO - 2021-07-04 05:51:17 --> Config Class Initialized
INFO - 2021-07-04 05:51:17 --> Loader Class Initialized
INFO - 2021-07-04 05:51:17 --> Helper loaded: url_helper
INFO - 2021-07-04 05:51:17 --> Helper loaded: file_helper
INFO - 2021-07-04 05:51:17 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:51:17 --> Database Driver Class Initialized
INFO - 2021-07-04 05:51:17 --> Email Class Initialized
INFO - 2021-07-04 05:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:51:17 --> Controller Class Initialized
DEBUG - 2021-07-04 05:51:17 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 05:51:17 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 05:51:17 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 05:51:17 --> Final output sent to browser
DEBUG - 2021-07-04 05:51:17 --> Total execution time: 0.0907
INFO - 2021-07-04 05:51:18 --> Config Class Initialized
INFO - 2021-07-04 05:51:18 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:51:18 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:51:18 --> Utf8 Class Initialized
INFO - 2021-07-04 05:51:18 --> URI Class Initialized
INFO - 2021-07-04 05:51:18 --> Router Class Initialized
INFO - 2021-07-04 05:51:18 --> Output Class Initialized
INFO - 2021-07-04 05:51:18 --> Security Class Initialized
DEBUG - 2021-07-04 05:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:51:18 --> Input Class Initialized
INFO - 2021-07-04 05:51:18 --> Config Class Initialized
INFO - 2021-07-04 05:51:18 --> Language Class Initialized
INFO - 2021-07-04 05:51:18 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:51:18 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:51:18 --> Utf8 Class Initialized
INFO - 2021-07-04 05:51:18 --> URI Class Initialized
INFO - 2021-07-04 05:51:18 --> Language Class Initialized
INFO - 2021-07-04 05:51:18 --> Config Class Initialized
INFO - 2021-07-04 05:51:18 --> Loader Class Initialized
INFO - 2021-07-04 05:51:18 --> Router Class Initialized
INFO - 2021-07-04 05:51:18 --> Helper loaded: url_helper
INFO - 2021-07-04 05:51:18 --> Helper loaded: file_helper
INFO - 2021-07-04 05:51:18 --> Output Class Initialized
INFO - 2021-07-04 05:51:18 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:51:18 --> Security Class Initialized
DEBUG - 2021-07-04 05:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:51:18 --> Input Class Initialized
INFO - 2021-07-04 05:51:18 --> Language Class Initialized
INFO - 2021-07-04 05:51:18 --> Database Driver Class Initialized
INFO - 2021-07-04 05:51:18 --> Language Class Initialized
INFO - 2021-07-04 05:51:18 --> Config Class Initialized
INFO - 2021-07-04 05:51:18 --> Loader Class Initialized
INFO - 2021-07-04 05:51:18 --> Helper loaded: url_helper
INFO - 2021-07-04 05:51:18 --> Helper loaded: file_helper
INFO - 2021-07-04 05:51:18 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:51:18 --> Email Class Initialized
INFO - 2021-07-04 05:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:51:18 --> Controller Class Initialized
INFO - 2021-07-04 05:51:18 --> Database Driver Class Initialized
DEBUG - 2021-07-04 05:51:18 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 05:51:18 --> Final output sent to browser
DEBUG - 2021-07-04 05:51:18 --> Total execution time: 0.1025
INFO - 2021-07-04 05:51:18 --> Email Class Initialized
INFO - 2021-07-04 05:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:51:18 --> Controller Class Initialized
DEBUG - 2021-07-04 05:51:18 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 05:51:18 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 05:51:18 --> Final output sent to browser
DEBUG - 2021-07-04 05:51:18 --> Total execution time: 0.0947
INFO - 2021-07-04 05:51:18 --> Config Class Initialized
INFO - 2021-07-04 05:51:18 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:51:18 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:51:18 --> Utf8 Class Initialized
INFO - 2021-07-04 05:51:18 --> URI Class Initialized
INFO - 2021-07-04 05:51:18 --> Router Class Initialized
INFO - 2021-07-04 05:51:18 --> Output Class Initialized
INFO - 2021-07-04 05:51:18 --> Security Class Initialized
DEBUG - 2021-07-04 05:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:51:18 --> Input Class Initialized
INFO - 2021-07-04 05:51:18 --> Language Class Initialized
INFO - 2021-07-04 05:51:18 --> Language Class Initialized
INFO - 2021-07-04 05:51:18 --> Config Class Initialized
INFO - 2021-07-04 05:51:18 --> Loader Class Initialized
INFO - 2021-07-04 05:51:18 --> Helper loaded: url_helper
INFO - 2021-07-04 05:51:18 --> Helper loaded: file_helper
INFO - 2021-07-04 05:51:18 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:51:18 --> Database Driver Class Initialized
INFO - 2021-07-04 05:51:18 --> Email Class Initialized
INFO - 2021-07-04 05:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:51:18 --> Controller Class Initialized
DEBUG - 2021-07-04 05:51:18 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 05:51:18 --> Final output sent to browser
DEBUG - 2021-07-04 05:51:18 --> Total execution time: 0.0951
INFO - 2021-07-04 05:51:20 --> Config Class Initialized
INFO - 2021-07-04 05:51:20 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:51:20 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:51:20 --> Utf8 Class Initialized
INFO - 2021-07-04 05:51:20 --> URI Class Initialized
INFO - 2021-07-04 05:51:20 --> Router Class Initialized
INFO - 2021-07-04 05:51:20 --> Output Class Initialized
INFO - 2021-07-04 05:51:20 --> Security Class Initialized
DEBUG - 2021-07-04 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:51:20 --> Input Class Initialized
INFO - 2021-07-04 05:51:20 --> Language Class Initialized
ERROR - 2021-07-04 05:51:20 --> 404 Page Not Found: ../modules/laporan/controllers/Laporan/index
INFO - 2021-07-04 05:52:58 --> Config Class Initialized
INFO - 2021-07-04 05:52:58 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:52:58 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:52:58 --> Utf8 Class Initialized
INFO - 2021-07-04 05:52:58 --> URI Class Initialized
INFO - 2021-07-04 05:52:58 --> Router Class Initialized
INFO - 2021-07-04 05:52:58 --> Output Class Initialized
INFO - 2021-07-04 05:52:58 --> Security Class Initialized
DEBUG - 2021-07-04 05:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:52:58 --> Input Class Initialized
INFO - 2021-07-04 05:52:58 --> Language Class Initialized
INFO - 2021-07-04 05:52:58 --> Language Class Initialized
INFO - 2021-07-04 05:52:58 --> Config Class Initialized
INFO - 2021-07-04 05:52:58 --> Loader Class Initialized
INFO - 2021-07-04 05:52:58 --> Helper loaded: url_helper
INFO - 2021-07-04 05:52:58 --> Helper loaded: file_helper
INFO - 2021-07-04 05:52:58 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:52:58 --> Database Driver Class Initialized
INFO - 2021-07-04 05:52:58 --> Email Class Initialized
INFO - 2021-07-04 05:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:52:58 --> Controller Class Initialized
DEBUG - 2021-07-04 05:52:58 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 05:52:58 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 05:52:58 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 05:52:58 --> Final output sent to browser
DEBUG - 2021-07-04 05:52:58 --> Total execution time: 0.0803
INFO - 2021-07-04 05:52:59 --> Config Class Initialized
INFO - 2021-07-04 05:52:59 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:52:59 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:52:59 --> Utf8 Class Initialized
INFO - 2021-07-04 05:52:59 --> URI Class Initialized
INFO - 2021-07-04 05:52:59 --> Router Class Initialized
INFO - 2021-07-04 05:52:59 --> Output Class Initialized
INFO - 2021-07-04 05:52:59 --> Security Class Initialized
DEBUG - 2021-07-04 05:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:52:59 --> Input Class Initialized
INFO - 2021-07-04 05:52:59 --> Language Class Initialized
INFO - 2021-07-04 05:52:59 --> Language Class Initialized
INFO - 2021-07-04 05:52:59 --> Config Class Initialized
INFO - 2021-07-04 05:52:59 --> Loader Class Initialized
INFO - 2021-07-04 05:52:59 --> Helper loaded: url_helper
INFO - 2021-07-04 05:52:59 --> Helper loaded: file_helper
INFO - 2021-07-04 05:52:59 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:52:59 --> Database Driver Class Initialized
INFO - 2021-07-04 05:52:59 --> Email Class Initialized
INFO - 2021-07-04 05:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:52:59 --> Controller Class Initialized
DEBUG - 2021-07-04 05:52:59 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 05:52:59 --> Final output sent to browser
DEBUG - 2021-07-04 05:52:59 --> Total execution time: 0.0968
INFO - 2021-07-04 05:59:43 --> Config Class Initialized
INFO - 2021-07-04 05:59:43 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:59:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:59:43 --> Utf8 Class Initialized
INFO - 2021-07-04 05:59:43 --> URI Class Initialized
INFO - 2021-07-04 05:59:43 --> Router Class Initialized
INFO - 2021-07-04 05:59:43 --> Output Class Initialized
INFO - 2021-07-04 05:59:43 --> Security Class Initialized
DEBUG - 2021-07-04 05:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:59:43 --> Input Class Initialized
INFO - 2021-07-04 05:59:43 --> Language Class Initialized
INFO - 2021-07-04 05:59:43 --> Language Class Initialized
INFO - 2021-07-04 05:59:43 --> Config Class Initialized
INFO - 2021-07-04 05:59:43 --> Loader Class Initialized
INFO - 2021-07-04 05:59:43 --> Helper loaded: url_helper
INFO - 2021-07-04 05:59:43 --> Helper loaded: file_helper
INFO - 2021-07-04 05:59:43 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:59:43 --> Database Driver Class Initialized
INFO - 2021-07-04 05:59:43 --> Email Class Initialized
INFO - 2021-07-04 05:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:59:43 --> Controller Class Initialized
DEBUG - 2021-07-04 05:59:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 05:59:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 05:59:43 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 05:59:43 --> Final output sent to browser
DEBUG - 2021-07-04 05:59:43 --> Total execution time: 0.0969
INFO - 2021-07-04 05:59:44 --> Config Class Initialized
INFO - 2021-07-04 05:59:44 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:59:44 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:59:44 --> Utf8 Class Initialized
INFO - 2021-07-04 05:59:44 --> URI Class Initialized
INFO - 2021-07-04 05:59:44 --> Router Class Initialized
INFO - 2021-07-04 05:59:44 --> Output Class Initialized
INFO - 2021-07-04 05:59:44 --> Security Class Initialized
DEBUG - 2021-07-04 05:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:59:44 --> Input Class Initialized
INFO - 2021-07-04 05:59:44 --> Language Class Initialized
INFO - 2021-07-04 05:59:44 --> Language Class Initialized
INFO - 2021-07-04 05:59:44 --> Config Class Initialized
INFO - 2021-07-04 05:59:44 --> Loader Class Initialized
INFO - 2021-07-04 05:59:44 --> Helper loaded: url_helper
INFO - 2021-07-04 05:59:44 --> Config Class Initialized
INFO - 2021-07-04 05:59:44 --> Helper loaded: file_helper
INFO - 2021-07-04 05:59:44 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:59:44 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:59:44 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:59:44 --> Utf8 Class Initialized
INFO - 2021-07-04 05:59:44 --> URI Class Initialized
INFO - 2021-07-04 05:59:44 --> Database Driver Class Initialized
INFO - 2021-07-04 05:59:44 --> Router Class Initialized
INFO - 2021-07-04 05:59:44 --> Output Class Initialized
INFO - 2021-07-04 05:59:44 --> Email Class Initialized
INFO - 2021-07-04 05:59:44 --> Security Class Initialized
DEBUG - 2021-07-04 05:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:59:44 --> Input Class Initialized
INFO - 2021-07-04 05:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:59:44 --> Language Class Initialized
INFO - 2021-07-04 05:59:44 --> Controller Class Initialized
DEBUG - 2021-07-04 05:59:44 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 05:59:44 --> Final output sent to browser
DEBUG - 2021-07-04 05:59:44 --> Total execution time: 0.0950
INFO - 2021-07-04 05:59:44 --> Language Class Initialized
INFO - 2021-07-04 05:59:44 --> Config Class Initialized
INFO - 2021-07-04 05:59:44 --> Loader Class Initialized
INFO - 2021-07-04 05:59:44 --> Helper loaded: url_helper
INFO - 2021-07-04 05:59:44 --> Helper loaded: file_helper
INFO - 2021-07-04 05:59:44 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:59:44 --> Database Driver Class Initialized
INFO - 2021-07-04 05:59:44 --> Email Class Initialized
INFO - 2021-07-04 05:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:59:44 --> Controller Class Initialized
DEBUG - 2021-07-04 05:59:44 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 05:59:44 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 05:59:44 --> Final output sent to browser
DEBUG - 2021-07-04 05:59:44 --> Total execution time: 0.1067
INFO - 2021-07-04 05:59:44 --> Config Class Initialized
INFO - 2021-07-04 05:59:44 --> Hooks Class Initialized
DEBUG - 2021-07-04 05:59:44 --> UTF-8 Support Enabled
INFO - 2021-07-04 05:59:44 --> Utf8 Class Initialized
INFO - 2021-07-04 05:59:44 --> URI Class Initialized
INFO - 2021-07-04 05:59:44 --> Router Class Initialized
INFO - 2021-07-04 05:59:44 --> Output Class Initialized
INFO - 2021-07-04 05:59:44 --> Security Class Initialized
DEBUG - 2021-07-04 05:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 05:59:44 --> Input Class Initialized
INFO - 2021-07-04 05:59:44 --> Language Class Initialized
INFO - 2021-07-04 05:59:44 --> Language Class Initialized
INFO - 2021-07-04 05:59:44 --> Config Class Initialized
INFO - 2021-07-04 05:59:44 --> Loader Class Initialized
INFO - 2021-07-04 05:59:44 --> Helper loaded: url_helper
INFO - 2021-07-04 05:59:44 --> Helper loaded: file_helper
INFO - 2021-07-04 05:59:44 --> Helper loaded: develop_helper
INFO - 2021-07-04 05:59:44 --> Database Driver Class Initialized
INFO - 2021-07-04 05:59:44 --> Email Class Initialized
INFO - 2021-07-04 05:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 05:59:44 --> Controller Class Initialized
DEBUG - 2021-07-04 05:59:44 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 05:59:44 --> Final output sent to browser
DEBUG - 2021-07-04 05:59:44 --> Total execution time: 0.1097
INFO - 2021-07-04 06:00:01 --> Config Class Initialized
INFO - 2021-07-04 06:00:01 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:01 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:01 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:01 --> URI Class Initialized
INFO - 2021-07-04 06:00:01 --> Router Class Initialized
INFO - 2021-07-04 06:00:01 --> Output Class Initialized
INFO - 2021-07-04 06:00:01 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:01 --> Input Class Initialized
INFO - 2021-07-04 06:00:01 --> Language Class Initialized
INFO - 2021-07-04 06:00:01 --> Language Class Initialized
INFO - 2021-07-04 06:00:01 --> Config Class Initialized
INFO - 2021-07-04 06:00:01 --> Loader Class Initialized
INFO - 2021-07-04 06:00:01 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:01 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:01 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:01 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:01 --> Email Class Initialized
INFO - 2021-07-04 06:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:01 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:01 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:00:01 --> Final output sent to browser
DEBUG - 2021-07-04 06:00:01 --> Total execution time: 0.0916
INFO - 2021-07-04 06:00:01 --> Config Class Initialized
INFO - 2021-07-04 06:00:01 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:01 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:01 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:01 --> URI Class Initialized
INFO - 2021-07-04 06:00:01 --> Router Class Initialized
INFO - 2021-07-04 06:00:01 --> Output Class Initialized
INFO - 2021-07-04 06:00:01 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:01 --> Input Class Initialized
INFO - 2021-07-04 06:00:01 --> Language Class Initialized
INFO - 2021-07-04 06:00:01 --> Language Class Initialized
INFO - 2021-07-04 06:00:01 --> Config Class Initialized
INFO - 2021-07-04 06:00:01 --> Loader Class Initialized
INFO - 2021-07-04 06:00:01 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:01 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:01 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:01 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:01 --> Email Class Initialized
INFO - 2021-07-04 06:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:01 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:01 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:00:01 --> Final output sent to browser
DEBUG - 2021-07-04 06:00:01 --> Total execution time: 0.0805
INFO - 2021-07-04 06:00:08 --> Config Class Initialized
INFO - 2021-07-04 06:00:08 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:08 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:08 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:08 --> URI Class Initialized
INFO - 2021-07-04 06:00:08 --> Router Class Initialized
INFO - 2021-07-04 06:00:08 --> Output Class Initialized
INFO - 2021-07-04 06:00:08 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:08 --> Input Class Initialized
INFO - 2021-07-04 06:00:08 --> Language Class Initialized
INFO - 2021-07-04 06:00:08 --> Language Class Initialized
INFO - 2021-07-04 06:00:08 --> Config Class Initialized
INFO - 2021-07-04 06:00:08 --> Loader Class Initialized
INFO - 2021-07-04 06:00:08 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:08 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:08 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:08 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:08 --> Email Class Initialized
INFO - 2021-07-04 06:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:08 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:08 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
ERROR - 2021-07-04 06:00:08 --> Query error: Table 'db_esi.m_kriteria_transaksi_detail' doesn't exist - Invalid query: select a.*,b.name as kriteria, b.id as id_cat_transaksi_detail from transaksi_detail a
		left join m_kriteria_transaksi_detail b on b.id = a.id_cat_transaksi_detail where a.id = '1' 
INFO - 2021-07-04 06:00:08 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-04 06:00:13 --> Config Class Initialized
INFO - 2021-07-04 06:00:13 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:13 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:13 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:13 --> URI Class Initialized
INFO - 2021-07-04 06:00:13 --> Router Class Initialized
INFO - 2021-07-04 06:00:13 --> Output Class Initialized
INFO - 2021-07-04 06:00:13 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:13 --> Input Class Initialized
INFO - 2021-07-04 06:00:13 --> Language Class Initialized
ERROR - 2021-07-04 06:00:13 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:00:13 --> Config Class Initialized
INFO - 2021-07-04 06:00:13 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:13 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:13 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:13 --> URI Class Initialized
INFO - 2021-07-04 06:00:13 --> Router Class Initialized
INFO - 2021-07-04 06:00:13 --> Output Class Initialized
INFO - 2021-07-04 06:00:13 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:13 --> Input Class Initialized
INFO - 2021-07-04 06:00:13 --> Language Class Initialized
INFO - 2021-07-04 06:00:13 --> Language Class Initialized
INFO - 2021-07-04 06:00:13 --> Config Class Initialized
INFO - 2021-07-04 06:00:13 --> Loader Class Initialized
INFO - 2021-07-04 06:00:13 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:13 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:13 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:13 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:13 --> Email Class Initialized
INFO - 2021-07-04 06:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:13 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:13 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 06:00:13 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 06:00:13 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:00:13 --> Final output sent to browser
DEBUG - 2021-07-04 06:00:13 --> Total execution time: 0.1041
INFO - 2021-07-04 06:00:17 --> Config Class Initialized
INFO - 2021-07-04 06:00:17 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:17 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:17 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:17 --> URI Class Initialized
INFO - 2021-07-04 06:00:17 --> Router Class Initialized
INFO - 2021-07-04 06:00:17 --> Output Class Initialized
INFO - 2021-07-04 06:00:17 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:17 --> Input Class Initialized
INFO - 2021-07-04 06:00:17 --> Language Class Initialized
INFO - 2021-07-04 06:00:17 --> Language Class Initialized
INFO - 2021-07-04 06:00:17 --> Config Class Initialized
INFO - 2021-07-04 06:00:17 --> Loader Class Initialized
INFO - 2021-07-04 06:00:17 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:17 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:17 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:17 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:17 --> Email Class Initialized
INFO - 2021-07-04 06:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:17 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:17 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 06:00:17 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 06:00:17 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:00:17 --> Final output sent to browser
DEBUG - 2021-07-04 06:00:17 --> Total execution time: 0.0804
INFO - 2021-07-04 06:00:19 --> Config Class Initialized
INFO - 2021-07-04 06:00:19 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:19 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:19 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:19 --> URI Class Initialized
INFO - 2021-07-04 06:00:19 --> Router Class Initialized
INFO - 2021-07-04 06:00:19 --> Output Class Initialized
INFO - 2021-07-04 06:00:19 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:19 --> Input Class Initialized
INFO - 2021-07-04 06:00:19 --> Language Class Initialized
INFO - 2021-07-04 06:00:19 --> Config Class Initialized
INFO - 2021-07-04 06:00:19 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:19 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:19 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:19 --> Language Class Initialized
INFO - 2021-07-04 06:00:19 --> URI Class Initialized
INFO - 2021-07-04 06:00:19 --> Config Class Initialized
INFO - 2021-07-04 06:00:19 --> Loader Class Initialized
INFO - 2021-07-04 06:00:19 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:19 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:19 --> Router Class Initialized
INFO - 2021-07-04 06:00:19 --> Output Class Initialized
INFO - 2021-07-04 06:00:19 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:19 --> Input Class Initialized
INFO - 2021-07-04 06:00:19 --> Language Class Initialized
INFO - 2021-07-04 06:00:19 --> Language Class Initialized
INFO - 2021-07-04 06:00:19 --> Config Class Initialized
INFO - 2021-07-04 06:00:19 --> Loader Class Initialized
INFO - 2021-07-04 06:00:19 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:19 --> Config Class Initialized
INFO - 2021-07-04 06:00:19 --> Hooks Class Initialized
INFO - 2021-07-04 06:00:19 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:19 --> Helper loaded: file_helper
DEBUG - 2021-07-04 06:00:19 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:19 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:19 --> URI Class Initialized
INFO - 2021-07-04 06:00:19 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:19 --> Email Class Initialized
INFO - 2021-07-04 06:00:19 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:19 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:19 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 06:00:19 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:00:19 --> Final output sent to browser
DEBUG - 2021-07-04 06:00:19 --> Total execution time: 0.1294
INFO - 2021-07-04 06:00:19 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:19 --> Router Class Initialized
INFO - 2021-07-04 06:00:19 --> Output Class Initialized
INFO - 2021-07-04 06:00:19 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:19 --> Input Class Initialized
INFO - 2021-07-04 06:00:19 --> Language Class Initialized
INFO - 2021-07-04 06:00:19 --> Email Class Initialized
INFO - 2021-07-04 06:00:19 --> Language Class Initialized
INFO - 2021-07-04 06:00:19 --> Config Class Initialized
INFO - 2021-07-04 06:00:19 --> Loader Class Initialized
INFO - 2021-07-04 06:00:19 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:19 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:19 --> Controller Class Initialized
INFO - 2021-07-04 06:00:19 --> Helper loaded: develop_helper
DEBUG - 2021-07-04 06:00:19 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:00:19 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:19 --> Final output sent to browser
DEBUG - 2021-07-04 06:00:19 --> Total execution time: 0.2146
INFO - 2021-07-04 06:00:19 --> Email Class Initialized
INFO - 2021-07-04 06:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:19 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:19 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 06:00:19 --> Final output sent to browser
DEBUG - 2021-07-04 06:00:19 --> Total execution time: 0.2537
INFO - 2021-07-04 06:00:20 --> Config Class Initialized
INFO - 2021-07-04 06:00:20 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:20 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:20 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:20 --> URI Class Initialized
INFO - 2021-07-04 06:00:20 --> Router Class Initialized
INFO - 2021-07-04 06:00:20 --> Output Class Initialized
INFO - 2021-07-04 06:00:20 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:20 --> Input Class Initialized
INFO - 2021-07-04 06:00:20 --> Language Class Initialized
ERROR - 2021-07-04 06:00:20 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:00:33 --> Config Class Initialized
INFO - 2021-07-04 06:00:33 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:00:33 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:00:33 --> Utf8 Class Initialized
INFO - 2021-07-04 06:00:33 --> URI Class Initialized
INFO - 2021-07-04 06:00:33 --> Router Class Initialized
INFO - 2021-07-04 06:00:33 --> Output Class Initialized
INFO - 2021-07-04 06:00:33 --> Security Class Initialized
DEBUG - 2021-07-04 06:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:00:33 --> Input Class Initialized
INFO - 2021-07-04 06:00:33 --> Language Class Initialized
INFO - 2021-07-04 06:00:33 --> Language Class Initialized
INFO - 2021-07-04 06:00:33 --> Config Class Initialized
INFO - 2021-07-04 06:00:33 --> Loader Class Initialized
INFO - 2021-07-04 06:00:33 --> Helper loaded: url_helper
INFO - 2021-07-04 06:00:33 --> Helper loaded: file_helper
INFO - 2021-07-04 06:00:33 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:00:33 --> Database Driver Class Initialized
INFO - 2021-07-04 06:00:33 --> Email Class Initialized
INFO - 2021-07-04 06:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:00:33 --> Controller Class Initialized
DEBUG - 2021-07-04 06:00:33 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
ERROR - 2021-07-04 06:00:33 --> Query error: Table 'db_esi.m_kriteria_transaksi_detail' doesn't exist - Invalid query: select a.*,b.name as kriteria, b.id as id_cat_transaksi_detail from transaksi_detail a
		left join m_kriteria_transaksi_detail b on b.id = a.id_cat_transaksi_detail where a.id = '1' 
INFO - 2021-07-04 06:00:33 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-04 06:01:43 --> Config Class Initialized
INFO - 2021-07-04 06:01:43 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:01:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:01:43 --> Utf8 Class Initialized
INFO - 2021-07-04 06:01:43 --> URI Class Initialized
INFO - 2021-07-04 06:01:43 --> Router Class Initialized
INFO - 2021-07-04 06:01:43 --> Output Class Initialized
INFO - 2021-07-04 06:01:43 --> Security Class Initialized
DEBUG - 2021-07-04 06:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:01:43 --> Input Class Initialized
INFO - 2021-07-04 06:01:43 --> Language Class Initialized
INFO - 2021-07-04 06:01:43 --> Language Class Initialized
INFO - 2021-07-04 06:01:43 --> Config Class Initialized
INFO - 2021-07-04 06:01:43 --> Loader Class Initialized
INFO - 2021-07-04 06:01:43 --> Helper loaded: url_helper
INFO - 2021-07-04 06:01:43 --> Helper loaded: file_helper
INFO - 2021-07-04 06:01:43 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:01:43 --> Database Driver Class Initialized
INFO - 2021-07-04 06:01:43 --> Email Class Initialized
INFO - 2021-07-04 06:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:01:43 --> Controller Class Initialized
DEBUG - 2021-07-04 06:01:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 06:01:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 06:01:43 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:01:43 --> Final output sent to browser
DEBUG - 2021-07-04 06:01:43 --> Total execution time: 0.0967
INFO - 2021-07-04 06:01:46 --> Config Class Initialized
INFO - 2021-07-04 06:01:46 --> Hooks Class Initialized
INFO - 2021-07-04 06:01:46 --> Config Class Initialized
INFO - 2021-07-04 06:01:46 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:01:46 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:01:46 --> Utf8 Class Initialized
DEBUG - 2021-07-04 06:01:46 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:01:46 --> Utf8 Class Initialized
INFO - 2021-07-04 06:01:46 --> URI Class Initialized
INFO - 2021-07-04 06:01:46 --> URI Class Initialized
INFO - 2021-07-04 06:01:46 --> Router Class Initialized
INFO - 2021-07-04 06:01:46 --> Config Class Initialized
INFO - 2021-07-04 06:01:46 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:01:46 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:01:46 --> Utf8 Class Initialized
INFO - 2021-07-04 06:01:46 --> URI Class Initialized
INFO - 2021-07-04 06:01:46 --> Router Class Initialized
INFO - 2021-07-04 06:01:46 --> Output Class Initialized
INFO - 2021-07-04 06:01:46 --> Router Class Initialized
INFO - 2021-07-04 06:01:46 --> Security Class Initialized
DEBUG - 2021-07-04 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:01:46 --> Input Class Initialized
INFO - 2021-07-04 06:01:46 --> Language Class Initialized
INFO - 2021-07-04 06:01:46 --> Language Class Initialized
INFO - 2021-07-04 06:01:46 --> Config Class Initialized
INFO - 2021-07-04 06:01:46 --> Loader Class Initialized
INFO - 2021-07-04 06:01:46 --> Output Class Initialized
INFO - 2021-07-04 06:01:46 --> Helper loaded: url_helper
INFO - 2021-07-04 06:01:46 --> Helper loaded: file_helper
INFO - 2021-07-04 06:01:46 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:01:46 --> Security Class Initialized
INFO - 2021-07-04 06:01:46 --> Output Class Initialized
DEBUG - 2021-07-04 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:01:46 --> Security Class Initialized
DEBUG - 2021-07-04 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:01:46 --> Input Class Initialized
INFO - 2021-07-04 06:01:46 --> Input Class Initialized
INFO - 2021-07-04 06:01:46 --> Language Class Initialized
INFO - 2021-07-04 06:01:46 --> Language Class Initialized
INFO - 2021-07-04 06:01:46 --> Language Class Initialized
INFO - 2021-07-04 06:01:46 --> Config Class Initialized
INFO - 2021-07-04 06:01:46 --> Loader Class Initialized
INFO - 2021-07-04 06:01:46 --> Helper loaded: url_helper
INFO - 2021-07-04 06:01:46 --> Language Class Initialized
INFO - 2021-07-04 06:01:46 --> Config Class Initialized
INFO - 2021-07-04 06:01:46 --> Loader Class Initialized
INFO - 2021-07-04 06:01:46 --> Helper loaded: url_helper
INFO - 2021-07-04 06:01:46 --> Helper loaded: file_helper
INFO - 2021-07-04 06:01:46 --> Database Driver Class Initialized
INFO - 2021-07-04 06:01:46 --> Helper loaded: file_helper
INFO - 2021-07-04 06:01:46 --> Email Class Initialized
INFO - 2021-07-04 06:01:46 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:01:46 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:01:46 --> Controller Class Initialized
DEBUG - 2021-07-04 06:01:46 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 06:01:46 --> Final output sent to browser
DEBUG - 2021-07-04 06:01:46 --> Total execution time: 0.1624
INFO - 2021-07-04 06:01:46 --> Database Driver Class Initialized
INFO - 2021-07-04 06:01:46 --> Database Driver Class Initialized
INFO - 2021-07-04 06:01:46 --> Email Class Initialized
INFO - 2021-07-04 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:01:46 --> Controller Class Initialized
DEBUG - 2021-07-04 06:01:46 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:01:46 --> Final output sent to browser
DEBUG - 2021-07-04 06:01:46 --> Total execution time: 0.1885
INFO - 2021-07-04 06:01:46 --> Email Class Initialized
INFO - 2021-07-04 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:01:46 --> Controller Class Initialized
DEBUG - 2021-07-04 06:01:46 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 06:01:46 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:01:46 --> Final output sent to browser
DEBUG - 2021-07-04 06:01:46 --> Total execution time: 0.2610
INFO - 2021-07-04 06:01:47 --> Config Class Initialized
INFO - 2021-07-04 06:01:47 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:01:47 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:01:47 --> Utf8 Class Initialized
INFO - 2021-07-04 06:01:47 --> URI Class Initialized
INFO - 2021-07-04 06:01:47 --> Router Class Initialized
INFO - 2021-07-04 06:01:47 --> Output Class Initialized
INFO - 2021-07-04 06:01:47 --> Security Class Initialized
DEBUG - 2021-07-04 06:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:01:47 --> Input Class Initialized
INFO - 2021-07-04 06:01:47 --> Language Class Initialized
ERROR - 2021-07-04 06:01:47 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:01:47 --> Config Class Initialized
INFO - 2021-07-04 06:01:47 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:01:47 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:01:47 --> Utf8 Class Initialized
INFO - 2021-07-04 06:01:47 --> URI Class Initialized
INFO - 2021-07-04 06:01:47 --> Router Class Initialized
INFO - 2021-07-04 06:01:47 --> Output Class Initialized
INFO - 2021-07-04 06:01:47 --> Security Class Initialized
DEBUG - 2021-07-04 06:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:01:47 --> Input Class Initialized
INFO - 2021-07-04 06:01:47 --> Language Class Initialized
INFO - 2021-07-04 06:01:47 --> Language Class Initialized
INFO - 2021-07-04 06:01:47 --> Config Class Initialized
INFO - 2021-07-04 06:01:47 --> Loader Class Initialized
INFO - 2021-07-04 06:01:47 --> Helper loaded: url_helper
INFO - 2021-07-04 06:01:47 --> Helper loaded: file_helper
INFO - 2021-07-04 06:01:47 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:01:47 --> Database Driver Class Initialized
INFO - 2021-07-04 06:01:47 --> Email Class Initialized
INFO - 2021-07-04 06:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:01:47 --> Controller Class Initialized
DEBUG - 2021-07-04 06:01:47 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:01:47 --> Final output sent to browser
DEBUG - 2021-07-04 06:01:47 --> Total execution time: 0.1139
INFO - 2021-07-04 06:02:49 --> Config Class Initialized
INFO - 2021-07-04 06:02:49 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:02:49 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:02:49 --> Utf8 Class Initialized
INFO - 2021-07-04 06:02:49 --> URI Class Initialized
INFO - 2021-07-04 06:02:49 --> Router Class Initialized
INFO - 2021-07-04 06:02:49 --> Output Class Initialized
INFO - 2021-07-04 06:02:49 --> Security Class Initialized
DEBUG - 2021-07-04 06:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:02:49 --> Input Class Initialized
INFO - 2021-07-04 06:02:49 --> Language Class Initialized
INFO - 2021-07-04 06:02:49 --> Language Class Initialized
INFO - 2021-07-04 06:02:49 --> Config Class Initialized
INFO - 2021-07-04 06:02:49 --> Loader Class Initialized
INFO - 2021-07-04 06:02:49 --> Helper loaded: url_helper
INFO - 2021-07-04 06:02:49 --> Helper loaded: file_helper
INFO - 2021-07-04 06:02:49 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:02:49 --> Database Driver Class Initialized
INFO - 2021-07-04 06:02:49 --> Email Class Initialized
INFO - 2021-07-04 06:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:02:49 --> Controller Class Initialized
DEBUG - 2021-07-04 06:02:49 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 06:02:49 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 06:02:49 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:02:49 --> Final output sent to browser
DEBUG - 2021-07-04 06:02:49 --> Total execution time: 0.0861
INFO - 2021-07-04 06:02:51 --> Config Class Initialized
INFO - 2021-07-04 06:02:51 --> Hooks Class Initialized
INFO - 2021-07-04 06:02:51 --> Config Class Initialized
INFO - 2021-07-04 06:02:51 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:02:51 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:02:51 --> Utf8 Class Initialized
INFO - 2021-07-04 06:02:51 --> URI Class Initialized
DEBUG - 2021-07-04 06:02:51 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:02:51 --> Utf8 Class Initialized
INFO - 2021-07-04 06:02:51 --> URI Class Initialized
INFO - 2021-07-04 06:02:51 --> Config Class Initialized
INFO - 2021-07-04 06:02:51 --> Router Class Initialized
INFO - 2021-07-04 06:02:51 --> Hooks Class Initialized
INFO - 2021-07-04 06:02:51 --> Output Class Initialized
INFO - 2021-07-04 06:02:51 --> Router Class Initialized
DEBUG - 2021-07-04 06:02:51 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:02:51 --> Utf8 Class Initialized
INFO - 2021-07-04 06:02:51 --> Security Class Initialized
INFO - 2021-07-04 06:02:51 --> Output Class Initialized
DEBUG - 2021-07-04 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:02:51 --> Input Class Initialized
INFO - 2021-07-04 06:02:51 --> Language Class Initialized
INFO - 2021-07-04 06:02:51 --> URI Class Initialized
INFO - 2021-07-04 06:02:51 --> Router Class Initialized
INFO - 2021-07-04 06:02:51 --> Security Class Initialized
DEBUG - 2021-07-04 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:02:51 --> Input Class Initialized
INFO - 2021-07-04 06:02:51 --> Language Class Initialized
INFO - 2021-07-04 06:02:51 --> Language Class Initialized
INFO - 2021-07-04 06:02:51 --> Config Class Initialized
INFO - 2021-07-04 06:02:51 --> Loader Class Initialized
INFO - 2021-07-04 06:02:51 --> Helper loaded: url_helper
INFO - 2021-07-04 06:02:51 --> Output Class Initialized
INFO - 2021-07-04 06:02:51 --> Helper loaded: file_helper
INFO - 2021-07-04 06:02:51 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:02:51 --> Security Class Initialized
INFO - 2021-07-04 06:02:51 --> Language Class Initialized
INFO - 2021-07-04 06:02:51 --> Database Driver Class Initialized
INFO - 2021-07-04 06:02:51 --> Config Class Initialized
INFO - 2021-07-04 06:02:51 --> Loader Class Initialized
DEBUG - 2021-07-04 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:02:51 --> Input Class Initialized
INFO - 2021-07-04 06:02:51 --> Helper loaded: url_helper
INFO - 2021-07-04 06:02:51 --> Language Class Initialized
INFO - 2021-07-04 06:02:51 --> Helper loaded: file_helper
INFO - 2021-07-04 06:02:51 --> Email Class Initialized
INFO - 2021-07-04 06:02:51 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:02:51 --> Language Class Initialized
INFO - 2021-07-04 06:02:51 --> Config Class Initialized
INFO - 2021-07-04 06:02:51 --> Loader Class Initialized
INFO - 2021-07-04 06:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:02:51 --> Controller Class Initialized
INFO - 2021-07-04 06:02:51 --> Helper loaded: url_helper
INFO - 2021-07-04 06:02:51 --> Helper loaded: file_helper
INFO - 2021-07-04 06:02:51 --> Helper loaded: develop_helper
DEBUG - 2021-07-04 06:02:51 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 06:02:51 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:02:51 --> Final output sent to browser
DEBUG - 2021-07-04 06:02:51 --> Total execution time: 0.1689
INFO - 2021-07-04 06:02:51 --> Database Driver Class Initialized
INFO - 2021-07-04 06:02:51 --> Email Class Initialized
INFO - 2021-07-04 06:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:02:51 --> Controller Class Initialized
DEBUG - 2021-07-04 06:02:51 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 06:02:51 --> Final output sent to browser
DEBUG - 2021-07-04 06:02:51 --> Total execution time: 0.2021
INFO - 2021-07-04 06:02:51 --> Database Driver Class Initialized
INFO - 2021-07-04 06:02:51 --> Email Class Initialized
INFO - 2021-07-04 06:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:02:51 --> Controller Class Initialized
DEBUG - 2021-07-04 06:02:51 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:02:51 --> Final output sent to browser
DEBUG - 2021-07-04 06:02:51 --> Total execution time: 0.2172
INFO - 2021-07-04 06:02:53 --> Config Class Initialized
INFO - 2021-07-04 06:02:53 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:02:53 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:02:53 --> Utf8 Class Initialized
INFO - 2021-07-04 06:02:53 --> URI Class Initialized
INFO - 2021-07-04 06:02:53 --> Router Class Initialized
INFO - 2021-07-04 06:02:53 --> Output Class Initialized
INFO - 2021-07-04 06:02:53 --> Security Class Initialized
DEBUG - 2021-07-04 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:02:53 --> Input Class Initialized
INFO - 2021-07-04 06:02:53 --> Language Class Initialized
ERROR - 2021-07-04 06:02:53 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:02:54 --> Config Class Initialized
INFO - 2021-07-04 06:02:54 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:02:54 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:02:54 --> Utf8 Class Initialized
INFO - 2021-07-04 06:02:54 --> URI Class Initialized
INFO - 2021-07-04 06:02:54 --> Router Class Initialized
INFO - 2021-07-04 06:02:54 --> Output Class Initialized
INFO - 2021-07-04 06:02:54 --> Security Class Initialized
DEBUG - 2021-07-04 06:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:02:54 --> Input Class Initialized
INFO - 2021-07-04 06:02:54 --> Language Class Initialized
INFO - 2021-07-04 06:02:54 --> Language Class Initialized
INFO - 2021-07-04 06:02:54 --> Config Class Initialized
INFO - 2021-07-04 06:02:54 --> Loader Class Initialized
INFO - 2021-07-04 06:02:54 --> Helper loaded: url_helper
INFO - 2021-07-04 06:02:54 --> Helper loaded: file_helper
INFO - 2021-07-04 06:02:54 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:02:54 --> Database Driver Class Initialized
INFO - 2021-07-04 06:02:54 --> Email Class Initialized
INFO - 2021-07-04 06:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:02:54 --> Controller Class Initialized
DEBUG - 2021-07-04 06:02:54 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:02:54 --> Final output sent to browser
DEBUG - 2021-07-04 06:02:54 --> Total execution time: 0.1217
INFO - 2021-07-04 06:03:22 --> Config Class Initialized
INFO - 2021-07-04 06:03:22 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:22 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:22 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:22 --> URI Class Initialized
INFO - 2021-07-04 06:03:22 --> Router Class Initialized
INFO - 2021-07-04 06:03:22 --> Output Class Initialized
INFO - 2021-07-04 06:03:22 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:22 --> Input Class Initialized
INFO - 2021-07-04 06:03:22 --> Language Class Initialized
INFO - 2021-07-04 06:03:22 --> Language Class Initialized
INFO - 2021-07-04 06:03:22 --> Config Class Initialized
INFO - 2021-07-04 06:03:22 --> Loader Class Initialized
INFO - 2021-07-04 06:03:22 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:22 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:22 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:22 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:22 --> Email Class Initialized
INFO - 2021-07-04 06:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:22 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:22 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 06:03:22 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 06:03:22 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:03:22 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:22 --> Total execution time: 0.0833
INFO - 2021-07-04 06:03:23 --> Config Class Initialized
INFO - 2021-07-04 06:03:23 --> Hooks Class Initialized
INFO - 2021-07-04 06:03:23 --> Config Class Initialized
INFO - 2021-07-04 06:03:23 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:23 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:23 --> Utf8 Class Initialized
DEBUG - 2021-07-04 06:03:23 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:23 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:23 --> URI Class Initialized
INFO - 2021-07-04 06:03:23 --> URI Class Initialized
INFO - 2021-07-04 06:03:23 --> Router Class Initialized
INFO - 2021-07-04 06:03:23 --> Router Class Initialized
INFO - 2021-07-04 06:03:23 --> Output Class Initialized
INFO - 2021-07-04 06:03:23 --> Output Class Initialized
INFO - 2021-07-04 06:03:23 --> Security Class Initialized
INFO - 2021-07-04 06:03:23 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:23 --> Input Class Initialized
DEBUG - 2021-07-04 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:23 --> Input Class Initialized
INFO - 2021-07-04 06:03:23 --> Language Class Initialized
INFO - 2021-07-04 06:03:23 --> Language Class Initialized
INFO - 2021-07-04 06:03:23 --> Language Class Initialized
INFO - 2021-07-04 06:03:23 --> Language Class Initialized
INFO - 2021-07-04 06:03:23 --> Config Class Initialized
INFO - 2021-07-04 06:03:23 --> Config Class Initialized
INFO - 2021-07-04 06:03:23 --> Loader Class Initialized
INFO - 2021-07-04 06:03:23 --> Loader Class Initialized
INFO - 2021-07-04 06:03:23 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:23 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:23 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:23 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:23 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:23 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:23 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:23 --> Email Class Initialized
INFO - 2021-07-04 06:03:23 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:23 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:23 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 06:03:23 --> Email Class Initialized
INFO - 2021-07-04 06:03:23 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:23 --> Total execution time: 0.1255
INFO - 2021-07-04 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:23 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:23 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 06:03:23 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:03:23 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:23 --> Total execution time: 0.1424
INFO - 2021-07-04 06:03:23 --> Config Class Initialized
INFO - 2021-07-04 06:03:23 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:23 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:23 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:23 --> URI Class Initialized
INFO - 2021-07-04 06:03:23 --> Router Class Initialized
INFO - 2021-07-04 06:03:23 --> Output Class Initialized
INFO - 2021-07-04 06:03:23 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:23 --> Input Class Initialized
INFO - 2021-07-04 06:03:23 --> Language Class Initialized
INFO - 2021-07-04 06:03:23 --> Language Class Initialized
INFO - 2021-07-04 06:03:23 --> Config Class Initialized
INFO - 2021-07-04 06:03:23 --> Loader Class Initialized
INFO - 2021-07-04 06:03:23 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:23 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:23 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:23 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:23 --> Email Class Initialized
INFO - 2021-07-04 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:23 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:23 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:03:23 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:23 --> Total execution time: 0.1179
INFO - 2021-07-04 06:03:25 --> Config Class Initialized
INFO - 2021-07-04 06:03:25 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:25 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:25 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:25 --> URI Class Initialized
INFO - 2021-07-04 06:03:25 --> Router Class Initialized
INFO - 2021-07-04 06:03:25 --> Output Class Initialized
INFO - 2021-07-04 06:03:25 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:25 --> Input Class Initialized
INFO - 2021-07-04 06:03:25 --> Language Class Initialized
ERROR - 2021-07-04 06:03:25 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:03:27 --> Config Class Initialized
INFO - 2021-07-04 06:03:27 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:27 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:27 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:27 --> URI Class Initialized
INFO - 2021-07-04 06:03:27 --> Router Class Initialized
INFO - 2021-07-04 06:03:27 --> Output Class Initialized
INFO - 2021-07-04 06:03:27 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:27 --> Input Class Initialized
INFO - 2021-07-04 06:03:27 --> Language Class Initialized
INFO - 2021-07-04 06:03:27 --> Language Class Initialized
INFO - 2021-07-04 06:03:27 --> Config Class Initialized
INFO - 2021-07-04 06:03:27 --> Loader Class Initialized
INFO - 2021-07-04 06:03:27 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:27 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:27 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:27 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:27 --> Email Class Initialized
INFO - 2021-07-04 06:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:27 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:27 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:03:27 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:27 --> Total execution time: 0.0964
INFO - 2021-07-04 06:03:41 --> Config Class Initialized
INFO - 2021-07-04 06:03:41 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:41 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:41 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:41 --> URI Class Initialized
INFO - 2021-07-04 06:03:41 --> Router Class Initialized
INFO - 2021-07-04 06:03:41 --> Output Class Initialized
INFO - 2021-07-04 06:03:41 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:41 --> Input Class Initialized
INFO - 2021-07-04 06:03:41 --> Language Class Initialized
INFO - 2021-07-04 06:03:41 --> Language Class Initialized
INFO - 2021-07-04 06:03:41 --> Config Class Initialized
INFO - 2021-07-04 06:03:41 --> Loader Class Initialized
INFO - 2021-07-04 06:03:41 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:41 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:41 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:41 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:41 --> Email Class Initialized
INFO - 2021-07-04 06:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:41 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:41 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 06:03:41 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 06:03:41 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:03:41 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:41 --> Total execution time: 0.0783
INFO - 2021-07-04 06:03:43 --> Config Class Initialized
INFO - 2021-07-04 06:03:43 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:43 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:43 --> URI Class Initialized
INFO - 2021-07-04 06:03:43 --> Router Class Initialized
INFO - 2021-07-04 06:03:43 --> Output Class Initialized
INFO - 2021-07-04 06:03:43 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:43 --> Config Class Initialized
INFO - 2021-07-04 06:03:43 --> Input Class Initialized
INFO - 2021-07-04 06:03:43 --> Config Class Initialized
INFO - 2021-07-04 06:03:43 --> Hooks Class Initialized
INFO - 2021-07-04 06:03:43 --> Language Class Initialized
DEBUG - 2021-07-04 06:03:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:43 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:43 --> URI Class Initialized
INFO - 2021-07-04 06:03:43 --> Language Class Initialized
INFO - 2021-07-04 06:03:43 --> Config Class Initialized
INFO - 2021-07-04 06:03:43 --> Loader Class Initialized
INFO - 2021-07-04 06:03:43 --> Router Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:43 --> Hooks Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: file_helper
DEBUG - 2021-07-04 06:03:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:43 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:43 --> URI Class Initialized
INFO - 2021-07-04 06:03:43 --> Output Class Initialized
INFO - 2021-07-04 06:03:43 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:43 --> Input Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:43 --> Language Class Initialized
INFO - 2021-07-04 06:03:43 --> Router Class Initialized
INFO - 2021-07-04 06:03:43 --> Language Class Initialized
INFO - 2021-07-04 06:03:43 --> Output Class Initialized
INFO - 2021-07-04 06:03:43 --> Config Class Initialized
INFO - 2021-07-04 06:03:43 --> Loader Class Initialized
INFO - 2021-07-04 06:03:43 --> Security Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: url_helper
DEBUG - 2021-07-04 06:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:43 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:43 --> Input Class Initialized
INFO - 2021-07-04 06:03:43 --> Language Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:43 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:43 --> Language Class Initialized
INFO - 2021-07-04 06:03:43 --> Config Class Initialized
INFO - 2021-07-04 06:03:43 --> Loader Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:43 --> Email Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:43 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 06:03:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:03:43 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:43 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:43 --> Email Class Initialized
INFO - 2021-07-04 06:03:43 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:43 --> Total execution time: 0.1754
INFO - 2021-07-04 06:03:43 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:43 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:03:43 --> Email Class Initialized
INFO - 2021-07-04 06:03:43 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:43 --> Total execution time: 0.1760
INFO - 2021-07-04 06:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:43 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 06:03:43 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:43 --> Total execution time: 0.1726
INFO - 2021-07-04 06:03:44 --> Config Class Initialized
INFO - 2021-07-04 06:03:44 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:44 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:44 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:44 --> URI Class Initialized
INFO - 2021-07-04 06:03:44 --> Router Class Initialized
INFO - 2021-07-04 06:03:44 --> Output Class Initialized
INFO - 2021-07-04 06:03:44 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:44 --> Input Class Initialized
INFO - 2021-07-04 06:03:44 --> Language Class Initialized
ERROR - 2021-07-04 06:03:44 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:03:54 --> Config Class Initialized
INFO - 2021-07-04 06:03:54 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:54 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:54 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:54 --> URI Class Initialized
INFO - 2021-07-04 06:03:54 --> Router Class Initialized
INFO - 2021-07-04 06:03:54 --> Output Class Initialized
INFO - 2021-07-04 06:03:54 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:54 --> Input Class Initialized
INFO - 2021-07-04 06:03:54 --> Language Class Initialized
INFO - 2021-07-04 06:03:54 --> Language Class Initialized
INFO - 2021-07-04 06:03:54 --> Config Class Initialized
INFO - 2021-07-04 06:03:54 --> Loader Class Initialized
INFO - 2021-07-04 06:03:54 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:54 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:54 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:54 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:54 --> Email Class Initialized
INFO - 2021-07-04 06:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:54 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:54 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
DEBUG - 2021-07-04 06:03:54 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/views/transaksi_detail_view.php
DEBUG - 2021-07-04 06:03:54 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:03:54 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:54 --> Total execution time: 0.0951
INFO - 2021-07-04 06:03:55 --> Config Class Initialized
INFO - 2021-07-04 06:03:55 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:55 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:55 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:55 --> URI Class Initialized
INFO - 2021-07-04 06:03:55 --> Config Class Initialized
INFO - 2021-07-04 06:03:55 --> Config Class Initialized
INFO - 2021-07-04 06:03:55 --> Hooks Class Initialized
INFO - 2021-07-04 06:03:55 --> Hooks Class Initialized
INFO - 2021-07-04 06:03:55 --> Router Class Initialized
INFO - 2021-07-04 06:03:55 --> Output Class Initialized
DEBUG - 2021-07-04 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-07-04 06:03:55 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:55 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:55 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:55 --> URI Class Initialized
INFO - 2021-07-04 06:03:55 --> URI Class Initialized
INFO - 2021-07-04 06:03:55 --> Router Class Initialized
INFO - 2021-07-04 06:03:55 --> Router Class Initialized
INFO - 2021-07-04 06:03:55 --> Security Class Initialized
INFO - 2021-07-04 06:03:55 --> Output Class Initialized
INFO - 2021-07-04 06:03:55 --> Output Class Initialized
INFO - 2021-07-04 06:03:55 --> Security Class Initialized
INFO - 2021-07-04 06:03:55 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-04 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:55 --> Input Class Initialized
DEBUG - 2021-07-04 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:55 --> Input Class Initialized
INFO - 2021-07-04 06:03:55 --> Input Class Initialized
INFO - 2021-07-04 06:03:55 --> Language Class Initialized
INFO - 2021-07-04 06:03:55 --> Language Class Initialized
INFO - 2021-07-04 06:03:56 --> Language Class Initialized
INFO - 2021-07-04 06:03:56 --> Config Class Initialized
INFO - 2021-07-04 06:03:56 --> Loader Class Initialized
INFO - 2021-07-04 06:03:56 --> Language Class Initialized
INFO - 2021-07-04 06:03:56 --> Language Class Initialized
INFO - 2021-07-04 06:03:56 --> Config Class Initialized
INFO - 2021-07-04 06:03:56 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:56 --> Loader Class Initialized
INFO - 2021-07-04 06:03:56 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:56 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:56 --> Language Class Initialized
INFO - 2021-07-04 06:03:56 --> Config Class Initialized
INFO - 2021-07-04 06:03:56 --> Loader Class Initialized
INFO - 2021-07-04 06:03:56 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:56 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:56 --> Email Class Initialized
INFO - 2021-07-04 06:03:56 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:56 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:56 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:56 --> Controller Class Initialized
INFO - 2021-07-04 06:03:56 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:56 --> Helper loaded: develop_helper
DEBUG - 2021-07-04 06:03:56 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:03:56 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:56 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:56 --> Total execution time: 0.1047
INFO - 2021-07-04 06:03:56 --> Email Class Initialized
INFO - 2021-07-04 06:03:56 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:56 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:56 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi/models/M_transaksi.php
INFO - 2021-07-04 06:03:56 --> Email Class Initialized
INFO - 2021-07-04 06:03:56 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:56 --> Total execution time: 0.1425
INFO - 2021-07-04 06:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:56 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:56 --> File loaded: C:\xampp\htdocs\esi\application\modules/buah/models/M_buah.php
DEBUG - 2021-07-04 06:03:56 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:03:56 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:56 --> Total execution time: 0.1449
INFO - 2021-07-04 06:03:57 --> Config Class Initialized
INFO - 2021-07-04 06:03:57 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:57 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:57 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:57 --> URI Class Initialized
INFO - 2021-07-04 06:03:57 --> Router Class Initialized
INFO - 2021-07-04 06:03:57 --> Output Class Initialized
INFO - 2021-07-04 06:03:57 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:57 --> Input Class Initialized
INFO - 2021-07-04 06:03:57 --> Language Class Initialized
ERROR - 2021-07-04 06:03:57 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:03:59 --> Config Class Initialized
INFO - 2021-07-04 06:03:59 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:03:59 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:03:59 --> Utf8 Class Initialized
INFO - 2021-07-04 06:03:59 --> URI Class Initialized
INFO - 2021-07-04 06:03:59 --> Router Class Initialized
INFO - 2021-07-04 06:03:59 --> Output Class Initialized
INFO - 2021-07-04 06:03:59 --> Security Class Initialized
DEBUG - 2021-07-04 06:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:03:59 --> Input Class Initialized
INFO - 2021-07-04 06:03:59 --> Language Class Initialized
INFO - 2021-07-04 06:03:59 --> Language Class Initialized
INFO - 2021-07-04 06:03:59 --> Config Class Initialized
INFO - 2021-07-04 06:03:59 --> Loader Class Initialized
INFO - 2021-07-04 06:03:59 --> Helper loaded: url_helper
INFO - 2021-07-04 06:03:59 --> Helper loaded: file_helper
INFO - 2021-07-04 06:03:59 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:03:59 --> Database Driver Class Initialized
INFO - 2021-07-04 06:03:59 --> Email Class Initialized
INFO - 2021-07-04 06:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:03:59 --> Controller Class Initialized
DEBUG - 2021-07-04 06:03:59 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:03:59 --> Final output sent to browser
DEBUG - 2021-07-04 06:03:59 --> Total execution time: 0.1088
INFO - 2021-07-04 06:04:12 --> Config Class Initialized
INFO - 2021-07-04 06:04:12 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:12 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:12 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:12 --> URI Class Initialized
INFO - 2021-07-04 06:04:12 --> Router Class Initialized
INFO - 2021-07-04 06:04:12 --> Output Class Initialized
INFO - 2021-07-04 06:04:12 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:12 --> Input Class Initialized
INFO - 2021-07-04 06:04:12 --> Language Class Initialized
INFO - 2021-07-04 06:04:12 --> Language Class Initialized
INFO - 2021-07-04 06:04:12 --> Config Class Initialized
INFO - 2021-07-04 06:04:12 --> Loader Class Initialized
INFO - 2021-07-04 06:04:12 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:12 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:12 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:12 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:12 --> Email Class Initialized
INFO - 2021-07-04 06:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:12 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:12 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:12 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:12 --> Total execution time: 0.0965
INFO - 2021-07-04 06:04:12 --> Config Class Initialized
INFO - 2021-07-04 06:04:12 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:12 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:12 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:12 --> URI Class Initialized
INFO - 2021-07-04 06:04:12 --> Router Class Initialized
INFO - 2021-07-04 06:04:12 --> Output Class Initialized
INFO - 2021-07-04 06:04:12 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:12 --> Input Class Initialized
INFO - 2021-07-04 06:04:12 --> Language Class Initialized
INFO - 2021-07-04 06:04:12 --> Language Class Initialized
INFO - 2021-07-04 06:04:12 --> Config Class Initialized
INFO - 2021-07-04 06:04:12 --> Loader Class Initialized
INFO - 2021-07-04 06:04:12 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:12 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:12 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:12 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:12 --> Email Class Initialized
INFO - 2021-07-04 06:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:12 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:12 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:12 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:12 --> Total execution time: 0.1291
INFO - 2021-07-04 06:04:43 --> Config Class Initialized
INFO - 2021-07-04 06:04:43 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:43 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:43 --> URI Class Initialized
INFO - 2021-07-04 06:04:43 --> Router Class Initialized
INFO - 2021-07-04 06:04:43 --> Output Class Initialized
INFO - 2021-07-04 06:04:43 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:43 --> Input Class Initialized
INFO - 2021-07-04 06:04:43 --> Language Class Initialized
INFO - 2021-07-04 06:04:43 --> Language Class Initialized
INFO - 2021-07-04 06:04:43 --> Config Class Initialized
INFO - 2021-07-04 06:04:43 --> Loader Class Initialized
INFO - 2021-07-04 06:04:43 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:43 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:43 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:43 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:43 --> Email Class Initialized
INFO - 2021-07-04 06:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:43 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:43 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:43 --> Total execution time: 0.0797
INFO - 2021-07-04 06:04:43 --> Config Class Initialized
INFO - 2021-07-04 06:04:43 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:43 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:43 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:43 --> URI Class Initialized
INFO - 2021-07-04 06:04:43 --> Router Class Initialized
INFO - 2021-07-04 06:04:43 --> Output Class Initialized
INFO - 2021-07-04 06:04:43 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:43 --> Input Class Initialized
INFO - 2021-07-04 06:04:43 --> Language Class Initialized
INFO - 2021-07-04 06:04:43 --> Language Class Initialized
INFO - 2021-07-04 06:04:43 --> Config Class Initialized
INFO - 2021-07-04 06:04:43 --> Loader Class Initialized
INFO - 2021-07-04 06:04:43 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:43 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:43 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:43 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:43 --> Email Class Initialized
INFO - 2021-07-04 06:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:43 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:43 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:43 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:43 --> Total execution time: 0.1128
INFO - 2021-07-04 06:04:45 --> Config Class Initialized
INFO - 2021-07-04 06:04:45 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:45 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:45 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:45 --> URI Class Initialized
INFO - 2021-07-04 06:04:45 --> Router Class Initialized
INFO - 2021-07-04 06:04:45 --> Output Class Initialized
INFO - 2021-07-04 06:04:45 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:45 --> Input Class Initialized
INFO - 2021-07-04 06:04:45 --> Language Class Initialized
INFO - 2021-07-04 06:04:45 --> Language Class Initialized
INFO - 2021-07-04 06:04:45 --> Config Class Initialized
INFO - 2021-07-04 06:04:45 --> Loader Class Initialized
INFO - 2021-07-04 06:04:45 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:45 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:45 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:45 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:45 --> Email Class Initialized
INFO - 2021-07-04 06:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:45 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:45 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:45 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:45 --> Total execution time: 0.0898
INFO - 2021-07-04 06:04:45 --> Config Class Initialized
INFO - 2021-07-04 06:04:45 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:45 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:45 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:45 --> URI Class Initialized
INFO - 2021-07-04 06:04:45 --> Router Class Initialized
INFO - 2021-07-04 06:04:45 --> Output Class Initialized
INFO - 2021-07-04 06:04:45 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:45 --> Input Class Initialized
INFO - 2021-07-04 06:04:45 --> Language Class Initialized
INFO - 2021-07-04 06:04:45 --> Language Class Initialized
INFO - 2021-07-04 06:04:45 --> Config Class Initialized
INFO - 2021-07-04 06:04:45 --> Loader Class Initialized
INFO - 2021-07-04 06:04:45 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:45 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:45 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:45 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:45 --> Email Class Initialized
INFO - 2021-07-04 06:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:45 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:45 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:45 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:45 --> Total execution time: 0.1098
INFO - 2021-07-04 06:04:55 --> Config Class Initialized
INFO - 2021-07-04 06:04:55 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:55 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:55 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:55 --> URI Class Initialized
INFO - 2021-07-04 06:04:55 --> Router Class Initialized
INFO - 2021-07-04 06:04:55 --> Output Class Initialized
INFO - 2021-07-04 06:04:55 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:55 --> Input Class Initialized
INFO - 2021-07-04 06:04:55 --> Language Class Initialized
INFO - 2021-07-04 06:04:55 --> Language Class Initialized
INFO - 2021-07-04 06:04:55 --> Config Class Initialized
INFO - 2021-07-04 06:04:55 --> Loader Class Initialized
INFO - 2021-07-04 06:04:55 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:55 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:55 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:55 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:55 --> Email Class Initialized
INFO - 2021-07-04 06:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:55 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:55 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:55 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:55 --> Total execution time: 0.0811
INFO - 2021-07-04 06:04:55 --> Config Class Initialized
INFO - 2021-07-04 06:04:55 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:04:56 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:04:56 --> Utf8 Class Initialized
INFO - 2021-07-04 06:04:56 --> URI Class Initialized
INFO - 2021-07-04 06:04:56 --> Router Class Initialized
INFO - 2021-07-04 06:04:56 --> Output Class Initialized
INFO - 2021-07-04 06:04:56 --> Security Class Initialized
DEBUG - 2021-07-04 06:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:04:56 --> Input Class Initialized
INFO - 2021-07-04 06:04:56 --> Language Class Initialized
INFO - 2021-07-04 06:04:56 --> Language Class Initialized
INFO - 2021-07-04 06:04:56 --> Config Class Initialized
INFO - 2021-07-04 06:04:56 --> Loader Class Initialized
INFO - 2021-07-04 06:04:56 --> Helper loaded: url_helper
INFO - 2021-07-04 06:04:56 --> Helper loaded: file_helper
INFO - 2021-07-04 06:04:56 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:04:56 --> Database Driver Class Initialized
INFO - 2021-07-04 06:04:56 --> Email Class Initialized
INFO - 2021-07-04 06:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:04:56 --> Controller Class Initialized
DEBUG - 2021-07-04 06:04:56 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:04:56 --> Final output sent to browser
DEBUG - 2021-07-04 06:04:56 --> Total execution time: 0.1197
INFO - 2021-07-04 06:05:05 --> Config Class Initialized
INFO - 2021-07-04 06:05:05 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:05:05 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:05:05 --> Utf8 Class Initialized
INFO - 2021-07-04 06:05:05 --> URI Class Initialized
INFO - 2021-07-04 06:05:05 --> Router Class Initialized
INFO - 2021-07-04 06:05:05 --> Output Class Initialized
INFO - 2021-07-04 06:05:05 --> Security Class Initialized
DEBUG - 2021-07-04 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:05:05 --> Input Class Initialized
INFO - 2021-07-04 06:05:05 --> Language Class Initialized
INFO - 2021-07-04 06:05:05 --> Language Class Initialized
INFO - 2021-07-04 06:05:05 --> Config Class Initialized
INFO - 2021-07-04 06:05:05 --> Loader Class Initialized
INFO - 2021-07-04 06:05:05 --> Helper loaded: url_helper
INFO - 2021-07-04 06:05:05 --> Helper loaded: file_helper
INFO - 2021-07-04 06:05:05 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:05:05 --> Database Driver Class Initialized
INFO - 2021-07-04 06:05:05 --> Email Class Initialized
INFO - 2021-07-04 06:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:05:05 --> Controller Class Initialized
DEBUG - 2021-07-04 06:05:05 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:05:05 --> Final output sent to browser
DEBUG - 2021-07-04 06:05:05 --> Total execution time: 0.0816
INFO - 2021-07-04 06:05:05 --> Config Class Initialized
INFO - 2021-07-04 06:05:05 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:05:05 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:05:05 --> Utf8 Class Initialized
INFO - 2021-07-04 06:05:05 --> URI Class Initialized
INFO - 2021-07-04 06:05:05 --> Router Class Initialized
INFO - 2021-07-04 06:05:05 --> Output Class Initialized
INFO - 2021-07-04 06:05:05 --> Security Class Initialized
DEBUG - 2021-07-04 06:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:05:05 --> Input Class Initialized
INFO - 2021-07-04 06:05:05 --> Language Class Initialized
INFO - 2021-07-04 06:05:05 --> Language Class Initialized
INFO - 2021-07-04 06:05:05 --> Config Class Initialized
INFO - 2021-07-04 06:05:05 --> Loader Class Initialized
INFO - 2021-07-04 06:05:05 --> Helper loaded: url_helper
INFO - 2021-07-04 06:05:05 --> Helper loaded: file_helper
INFO - 2021-07-04 06:05:05 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:05:05 --> Database Driver Class Initialized
INFO - 2021-07-04 06:05:05 --> Email Class Initialized
INFO - 2021-07-04 06:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:05:05 --> Controller Class Initialized
DEBUG - 2021-07-04 06:05:05 --> File loaded: C:\xampp\htdocs\esi\application\modules/transaksi_detail/models/M_transaksi_detail.php
INFO - 2021-07-04 06:05:05 --> Final output sent to browser
DEBUG - 2021-07-04 06:05:05 --> Total execution time: 0.1354
INFO - 2021-07-04 06:09:31 --> Config Class Initialized
INFO - 2021-07-04 06:09:31 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:09:31 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:09:31 --> Utf8 Class Initialized
INFO - 2021-07-04 06:09:31 --> URI Class Initialized
INFO - 2021-07-04 06:09:31 --> Router Class Initialized
INFO - 2021-07-04 06:09:31 --> Output Class Initialized
INFO - 2021-07-04 06:09:31 --> Security Class Initialized
DEBUG - 2021-07-04 06:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:09:31 --> Input Class Initialized
INFO - 2021-07-04 06:09:31 --> Language Class Initialized
INFO - 2021-07-04 06:09:31 --> Language Class Initialized
INFO - 2021-07-04 06:09:31 --> Config Class Initialized
INFO - 2021-07-04 06:09:31 --> Loader Class Initialized
INFO - 2021-07-04 06:09:31 --> Helper loaded: url_helper
INFO - 2021-07-04 06:09:31 --> Helper loaded: file_helper
INFO - 2021-07-04 06:09:32 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:09:32 --> Database Driver Class Initialized
INFO - 2021-07-04 06:09:32 --> Email Class Initialized
INFO - 2021-07-04 06:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:09:32 --> Controller Class Initialized
DEBUG - 2021-07-04 06:09:32 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:09:32 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:09:32 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:09:32 --> Final output sent to browser
DEBUG - 2021-07-04 06:09:32 --> Total execution time: 0.0887
INFO - 2021-07-04 06:09:33 --> Config Class Initialized
INFO - 2021-07-04 06:09:33 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:09:33 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:09:33 --> Utf8 Class Initialized
INFO - 2021-07-04 06:09:33 --> URI Class Initialized
INFO - 2021-07-04 06:09:33 --> Router Class Initialized
INFO - 2021-07-04 06:09:33 --> Output Class Initialized
INFO - 2021-07-04 06:09:33 --> Security Class Initialized
DEBUG - 2021-07-04 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:09:33 --> Input Class Initialized
INFO - 2021-07-04 06:09:33 --> Language Class Initialized
INFO - 2021-07-04 06:09:33 --> Language Class Initialized
INFO - 2021-07-04 06:09:33 --> Config Class Initialized
INFO - 2021-07-04 06:09:33 --> Loader Class Initialized
INFO - 2021-07-04 06:09:33 --> Helper loaded: url_helper
INFO - 2021-07-04 06:09:33 --> Helper loaded: file_helper
INFO - 2021-07-04 06:09:33 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:09:33 --> Database Driver Class Initialized
INFO - 2021-07-04 06:09:33 --> Email Class Initialized
INFO - 2021-07-04 06:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:09:33 --> Controller Class Initialized
DEBUG - 2021-07-04 06:09:33 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:09:33 --> Final output sent to browser
DEBUG - 2021-07-04 06:09:33 --> Total execution time: 0.1016
INFO - 2021-07-04 06:09:34 --> Config Class Initialized
INFO - 2021-07-04 06:09:34 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:09:34 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:09:34 --> Utf8 Class Initialized
INFO - 2021-07-04 06:09:34 --> URI Class Initialized
INFO - 2021-07-04 06:09:34 --> Router Class Initialized
INFO - 2021-07-04 06:09:34 --> Output Class Initialized
INFO - 2021-07-04 06:09:34 --> Security Class Initialized
DEBUG - 2021-07-04 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:09:34 --> Input Class Initialized
INFO - 2021-07-04 06:09:34 --> Language Class Initialized
ERROR - 2021-07-04 06:09:34 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:48:28 --> Config Class Initialized
INFO - 2021-07-04 06:48:28 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:48:28 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:48:28 --> Utf8 Class Initialized
INFO - 2021-07-04 06:48:28 --> URI Class Initialized
INFO - 2021-07-04 06:48:28 --> Router Class Initialized
INFO - 2021-07-04 06:48:28 --> Output Class Initialized
INFO - 2021-07-04 06:48:28 --> Security Class Initialized
DEBUG - 2021-07-04 06:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:48:28 --> Input Class Initialized
INFO - 2021-07-04 06:48:28 --> Language Class Initialized
INFO - 2021-07-04 06:48:28 --> Language Class Initialized
INFO - 2021-07-04 06:48:28 --> Config Class Initialized
INFO - 2021-07-04 06:48:28 --> Loader Class Initialized
INFO - 2021-07-04 06:48:28 --> Helper loaded: url_helper
INFO - 2021-07-04 06:48:28 --> Helper loaded: file_helper
INFO - 2021-07-04 06:48:28 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:48:28 --> Database Driver Class Initialized
INFO - 2021-07-04 06:48:28 --> Email Class Initialized
INFO - 2021-07-04 06:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:48:28 --> Controller Class Initialized
DEBUG - 2021-07-04 06:48:28 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:48:28 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:48:28 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:48:28 --> Final output sent to browser
DEBUG - 2021-07-04 06:48:28 --> Total execution time: 0.1087
INFO - 2021-07-04 06:48:29 --> Config Class Initialized
INFO - 2021-07-04 06:48:29 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:48:29 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:48:29 --> Utf8 Class Initialized
INFO - 2021-07-04 06:48:29 --> URI Class Initialized
INFO - 2021-07-04 06:48:29 --> Router Class Initialized
INFO - 2021-07-04 06:48:29 --> Output Class Initialized
INFO - 2021-07-04 06:48:29 --> Security Class Initialized
DEBUG - 2021-07-04 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:48:29 --> Input Class Initialized
INFO - 2021-07-04 06:48:29 --> Language Class Initialized
INFO - 2021-07-04 06:48:29 --> Language Class Initialized
INFO - 2021-07-04 06:48:29 --> Config Class Initialized
INFO - 2021-07-04 06:48:29 --> Loader Class Initialized
INFO - 2021-07-04 06:48:29 --> Helper loaded: url_helper
INFO - 2021-07-04 06:48:29 --> Helper loaded: file_helper
INFO - 2021-07-04 06:48:29 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:48:29 --> Database Driver Class Initialized
INFO - 2021-07-04 06:48:29 --> Email Class Initialized
INFO - 2021-07-04 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:48:29 --> Controller Class Initialized
DEBUG - 2021-07-04 06:48:29 --> File loaded: C:\xampp\htdocs\esi\application\modules/kriteria_buah/models/M_kriteria_buah.php
INFO - 2021-07-04 06:48:29 --> Final output sent to browser
DEBUG - 2021-07-04 06:48:29 --> Total execution time: 0.1533
INFO - 2021-07-04 06:48:31 --> Config Class Initialized
INFO - 2021-07-04 06:48:31 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:48:31 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:48:31 --> Utf8 Class Initialized
INFO - 2021-07-04 06:48:31 --> URI Class Initialized
INFO - 2021-07-04 06:48:31 --> Router Class Initialized
INFO - 2021-07-04 06:48:31 --> Output Class Initialized
INFO - 2021-07-04 06:48:31 --> Security Class Initialized
DEBUG - 2021-07-04 06:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:48:31 --> Input Class Initialized
INFO - 2021-07-04 06:48:31 --> Language Class Initialized
ERROR - 2021-07-04 06:48:31 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:48:51 --> Config Class Initialized
INFO - 2021-07-04 06:48:51 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:48:51 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:48:51 --> Utf8 Class Initialized
INFO - 2021-07-04 06:48:51 --> URI Class Initialized
INFO - 2021-07-04 06:48:51 --> Router Class Initialized
INFO - 2021-07-04 06:48:51 --> Output Class Initialized
INFO - 2021-07-04 06:48:51 --> Security Class Initialized
DEBUG - 2021-07-04 06:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:48:51 --> Input Class Initialized
INFO - 2021-07-04 06:48:51 --> Language Class Initialized
INFO - 2021-07-04 06:48:51 --> Language Class Initialized
INFO - 2021-07-04 06:48:51 --> Config Class Initialized
INFO - 2021-07-04 06:48:51 --> Loader Class Initialized
INFO - 2021-07-04 06:48:51 --> Helper loaded: url_helper
INFO - 2021-07-04 06:48:51 --> Helper loaded: file_helper
INFO - 2021-07-04 06:48:51 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:48:51 --> Database Driver Class Initialized
INFO - 2021-07-04 06:48:51 --> Email Class Initialized
INFO - 2021-07-04 06:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:48:51 --> Controller Class Initialized
DEBUG - 2021-07-04 06:48:51 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:48:51 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:48:51 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:48:51 --> Final output sent to browser
DEBUG - 2021-07-04 06:48:51 --> Total execution time: 0.0774
INFO - 2021-07-04 06:48:52 --> Config Class Initialized
INFO - 2021-07-04 06:48:52 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:48:52 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:48:52 --> Utf8 Class Initialized
INFO - 2021-07-04 06:48:52 --> URI Class Initialized
INFO - 2021-07-04 06:48:52 --> Router Class Initialized
INFO - 2021-07-04 06:48:52 --> Output Class Initialized
INFO - 2021-07-04 06:48:52 --> Security Class Initialized
DEBUG - 2021-07-04 06:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:48:52 --> Input Class Initialized
INFO - 2021-07-04 06:48:52 --> Language Class Initialized
INFO - 2021-07-04 06:48:52 --> Language Class Initialized
INFO - 2021-07-04 06:48:52 --> Config Class Initialized
INFO - 2021-07-04 06:48:52 --> Loader Class Initialized
INFO - 2021-07-04 06:48:52 --> Helper loaded: url_helper
INFO - 2021-07-04 06:48:52 --> Helper loaded: file_helper
INFO - 2021-07-04 06:48:52 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:48:52 --> Database Driver Class Initialized
INFO - 2021-07-04 06:48:52 --> Email Class Initialized
INFO - 2021-07-04 06:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:48:52 --> Controller Class Initialized
DEBUG - 2021-07-04 06:48:52 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 06:48:52 --> Final output sent to browser
DEBUG - 2021-07-04 06:48:52 --> Total execution time: 0.1125
INFO - 2021-07-04 06:48:53 --> Config Class Initialized
INFO - 2021-07-04 06:48:53 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:48:53 --> Utf8 Class Initialized
INFO - 2021-07-04 06:48:53 --> URI Class Initialized
INFO - 2021-07-04 06:48:53 --> Router Class Initialized
INFO - 2021-07-04 06:48:53 --> Output Class Initialized
INFO - 2021-07-04 06:48:53 --> Security Class Initialized
DEBUG - 2021-07-04 06:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:48:53 --> Input Class Initialized
INFO - 2021-07-04 06:48:53 --> Language Class Initialized
ERROR - 2021-07-04 06:48:53 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:49:29 --> Config Class Initialized
INFO - 2021-07-04 06:49:29 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:49:29 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:49:29 --> Utf8 Class Initialized
INFO - 2021-07-04 06:49:29 --> URI Class Initialized
INFO - 2021-07-04 06:49:29 --> Router Class Initialized
INFO - 2021-07-04 06:49:29 --> Output Class Initialized
INFO - 2021-07-04 06:49:29 --> Security Class Initialized
DEBUG - 2021-07-04 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:49:29 --> Input Class Initialized
INFO - 2021-07-04 06:49:29 --> Language Class Initialized
INFO - 2021-07-04 06:49:29 --> Language Class Initialized
INFO - 2021-07-04 06:49:29 --> Config Class Initialized
INFO - 2021-07-04 06:49:29 --> Loader Class Initialized
INFO - 2021-07-04 06:49:29 --> Helper loaded: url_helper
INFO - 2021-07-04 06:49:29 --> Helper loaded: file_helper
INFO - 2021-07-04 06:49:29 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:49:29 --> Database Driver Class Initialized
INFO - 2021-07-04 06:49:29 --> Email Class Initialized
INFO - 2021-07-04 06:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:49:29 --> Controller Class Initialized
DEBUG - 2021-07-04 06:49:29 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:49:29 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:49:29 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:49:29 --> Final output sent to browser
DEBUG - 2021-07-04 06:49:29 --> Total execution time: 0.0889
INFO - 2021-07-04 06:49:31 --> Config Class Initialized
INFO - 2021-07-04 06:49:31 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:49:31 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:49:31 --> Utf8 Class Initialized
INFO - 2021-07-04 06:49:31 --> URI Class Initialized
INFO - 2021-07-04 06:49:31 --> Router Class Initialized
INFO - 2021-07-04 06:49:31 --> Output Class Initialized
INFO - 2021-07-04 06:49:31 --> Security Class Initialized
DEBUG - 2021-07-04 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:49:31 --> Input Class Initialized
INFO - 2021-07-04 06:49:31 --> Language Class Initialized
INFO - 2021-07-04 06:49:31 --> Language Class Initialized
INFO - 2021-07-04 06:49:31 --> Config Class Initialized
INFO - 2021-07-04 06:49:31 --> Loader Class Initialized
INFO - 2021-07-04 06:49:31 --> Helper loaded: url_helper
INFO - 2021-07-04 06:49:31 --> Helper loaded: file_helper
INFO - 2021-07-04 06:49:31 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:49:31 --> Database Driver Class Initialized
INFO - 2021-07-04 06:49:31 --> Email Class Initialized
INFO - 2021-07-04 06:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:49:31 --> Controller Class Initialized
DEBUG - 2021-07-04 06:49:31 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 06:49:31 --> Final output sent to browser
DEBUG - 2021-07-04 06:49:31 --> Total execution time: 0.1167
INFO - 2021-07-04 06:49:31 --> Config Class Initialized
INFO - 2021-07-04 06:49:31 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:49:31 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:49:31 --> Utf8 Class Initialized
INFO - 2021-07-04 06:49:31 --> URI Class Initialized
INFO - 2021-07-04 06:49:31 --> Router Class Initialized
INFO - 2021-07-04 06:49:31 --> Output Class Initialized
INFO - 2021-07-04 06:49:31 --> Security Class Initialized
DEBUG - 2021-07-04 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:49:31 --> Input Class Initialized
INFO - 2021-07-04 06:49:31 --> Language Class Initialized
ERROR - 2021-07-04 06:49:31 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:49:53 --> Config Class Initialized
INFO - 2021-07-04 06:49:53 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:49:53 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:49:53 --> Utf8 Class Initialized
INFO - 2021-07-04 06:49:53 --> URI Class Initialized
INFO - 2021-07-04 06:49:53 --> Router Class Initialized
INFO - 2021-07-04 06:49:53 --> Output Class Initialized
INFO - 2021-07-04 06:49:53 --> Security Class Initialized
DEBUG - 2021-07-04 06:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:49:53 --> Input Class Initialized
INFO - 2021-07-04 06:49:53 --> Language Class Initialized
INFO - 2021-07-04 06:49:53 --> Language Class Initialized
INFO - 2021-07-04 06:49:53 --> Config Class Initialized
INFO - 2021-07-04 06:49:53 --> Loader Class Initialized
INFO - 2021-07-04 06:49:53 --> Helper loaded: url_helper
INFO - 2021-07-04 06:49:53 --> Helper loaded: file_helper
INFO - 2021-07-04 06:49:54 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:49:54 --> Database Driver Class Initialized
INFO - 2021-07-04 06:49:54 --> Email Class Initialized
INFO - 2021-07-04 06:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:49:54 --> Controller Class Initialized
DEBUG - 2021-07-04 06:49:54 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:49:54 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:49:54 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:49:54 --> Final output sent to browser
DEBUG - 2021-07-04 06:49:54 --> Total execution time: 0.0895
INFO - 2021-07-04 06:49:56 --> Config Class Initialized
INFO - 2021-07-04 06:49:56 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:49:56 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:49:56 --> Utf8 Class Initialized
INFO - 2021-07-04 06:49:56 --> URI Class Initialized
INFO - 2021-07-04 06:49:56 --> Router Class Initialized
INFO - 2021-07-04 06:49:56 --> Output Class Initialized
INFO - 2021-07-04 06:49:56 --> Security Class Initialized
DEBUG - 2021-07-04 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:49:56 --> Input Class Initialized
INFO - 2021-07-04 06:49:56 --> Language Class Initialized
INFO - 2021-07-04 06:49:56 --> Language Class Initialized
INFO - 2021-07-04 06:49:56 --> Config Class Initialized
INFO - 2021-07-04 06:49:56 --> Loader Class Initialized
INFO - 2021-07-04 06:49:56 --> Helper loaded: url_helper
INFO - 2021-07-04 06:49:56 --> Helper loaded: file_helper
INFO - 2021-07-04 06:49:56 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:49:56 --> Database Driver Class Initialized
INFO - 2021-07-04 06:49:56 --> Email Class Initialized
INFO - 2021-07-04 06:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:49:56 --> Controller Class Initialized
DEBUG - 2021-07-04 06:49:56 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 06:49:56 --> Final output sent to browser
DEBUG - 2021-07-04 06:49:56 --> Total execution time: 0.2351
INFO - 2021-07-04 06:49:59 --> Config Class Initialized
INFO - 2021-07-04 06:49:59 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:49:59 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:49:59 --> Utf8 Class Initialized
INFO - 2021-07-04 06:49:59 --> URI Class Initialized
INFO - 2021-07-04 06:49:59 --> Router Class Initialized
INFO - 2021-07-04 06:49:59 --> Output Class Initialized
INFO - 2021-07-04 06:49:59 --> Security Class Initialized
DEBUG - 2021-07-04 06:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:49:59 --> Input Class Initialized
INFO - 2021-07-04 06:49:59 --> Language Class Initialized
ERROR - 2021-07-04 06:49:59 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:53:47 --> Config Class Initialized
INFO - 2021-07-04 06:53:47 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:53:47 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:53:47 --> Utf8 Class Initialized
INFO - 2021-07-04 06:53:47 --> URI Class Initialized
INFO - 2021-07-04 06:53:47 --> Router Class Initialized
INFO - 2021-07-04 06:53:47 --> Output Class Initialized
INFO - 2021-07-04 06:53:47 --> Security Class Initialized
DEBUG - 2021-07-04 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:53:47 --> Input Class Initialized
INFO - 2021-07-04 06:53:47 --> Language Class Initialized
INFO - 2021-07-04 06:53:47 --> Language Class Initialized
INFO - 2021-07-04 06:53:47 --> Config Class Initialized
INFO - 2021-07-04 06:53:47 --> Loader Class Initialized
INFO - 2021-07-04 06:53:47 --> Helper loaded: url_helper
INFO - 2021-07-04 06:53:47 --> Helper loaded: file_helper
INFO - 2021-07-04 06:53:47 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:53:47 --> Database Driver Class Initialized
INFO - 2021-07-04 06:53:47 --> Email Class Initialized
INFO - 2021-07-04 06:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:53:47 --> Controller Class Initialized
DEBUG - 2021-07-04 06:53:47 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:53:47 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:53:47 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:53:47 --> Final output sent to browser
DEBUG - 2021-07-04 06:53:47 --> Total execution time: 0.1049
INFO - 2021-07-04 06:53:48 --> Config Class Initialized
INFO - 2021-07-04 06:53:48 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:53:48 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:53:48 --> Utf8 Class Initialized
INFO - 2021-07-04 06:53:48 --> URI Class Initialized
INFO - 2021-07-04 06:53:48 --> Router Class Initialized
INFO - 2021-07-04 06:53:48 --> Output Class Initialized
INFO - 2021-07-04 06:53:48 --> Security Class Initialized
DEBUG - 2021-07-04 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:53:48 --> Input Class Initialized
INFO - 2021-07-04 06:53:48 --> Language Class Initialized
INFO - 2021-07-04 06:53:48 --> Language Class Initialized
INFO - 2021-07-04 06:53:48 --> Config Class Initialized
INFO - 2021-07-04 06:53:48 --> Loader Class Initialized
INFO - 2021-07-04 06:53:48 --> Helper loaded: url_helper
INFO - 2021-07-04 06:53:49 --> Helper loaded: file_helper
INFO - 2021-07-04 06:53:49 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:53:49 --> Database Driver Class Initialized
INFO - 2021-07-04 06:53:49 --> Email Class Initialized
INFO - 2021-07-04 06:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:53:49 --> Controller Class Initialized
DEBUG - 2021-07-04 06:53:49 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 06:53:49 --> Final output sent to browser
DEBUG - 2021-07-04 06:53:49 --> Total execution time: 0.1780
INFO - 2021-07-04 06:53:51 --> Config Class Initialized
INFO - 2021-07-04 06:53:51 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:53:51 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:53:51 --> Utf8 Class Initialized
INFO - 2021-07-04 06:53:51 --> URI Class Initialized
INFO - 2021-07-04 06:53:51 --> Router Class Initialized
INFO - 2021-07-04 06:53:51 --> Output Class Initialized
INFO - 2021-07-04 06:53:51 --> Security Class Initialized
DEBUG - 2021-07-04 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:53:51 --> Input Class Initialized
INFO - 2021-07-04 06:53:51 --> Language Class Initialized
ERROR - 2021-07-04 06:53:51 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:54:12 --> Config Class Initialized
INFO - 2021-07-04 06:54:12 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:54:12 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:54:12 --> Utf8 Class Initialized
INFO - 2021-07-04 06:54:12 --> URI Class Initialized
INFO - 2021-07-04 06:54:12 --> Router Class Initialized
INFO - 2021-07-04 06:54:12 --> Output Class Initialized
INFO - 2021-07-04 06:54:12 --> Security Class Initialized
DEBUG - 2021-07-04 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:54:12 --> Input Class Initialized
INFO - 2021-07-04 06:54:12 --> Language Class Initialized
INFO - 2021-07-04 06:54:12 --> Language Class Initialized
INFO - 2021-07-04 06:54:12 --> Config Class Initialized
INFO - 2021-07-04 06:54:12 --> Loader Class Initialized
INFO - 2021-07-04 06:54:12 --> Helper loaded: url_helper
INFO - 2021-07-04 06:54:12 --> Helper loaded: file_helper
INFO - 2021-07-04 06:54:12 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:54:12 --> Database Driver Class Initialized
INFO - 2021-07-04 06:54:12 --> Email Class Initialized
INFO - 2021-07-04 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:54:12 --> Controller Class Initialized
DEBUG - 2021-07-04 06:54:12 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:54:12 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:54:12 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:54:12 --> Final output sent to browser
DEBUG - 2021-07-04 06:54:12 --> Total execution time: 0.1650
INFO - 2021-07-04 06:54:14 --> Config Class Initialized
INFO - 2021-07-04 06:54:14 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:54:14 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:54:14 --> Utf8 Class Initialized
INFO - 2021-07-04 06:54:14 --> URI Class Initialized
INFO - 2021-07-04 06:54:14 --> Config Class Initialized
INFO - 2021-07-04 06:54:14 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:54:14 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:54:14 --> Utf8 Class Initialized
INFO - 2021-07-04 06:54:14 --> URI Class Initialized
INFO - 2021-07-04 06:54:14 --> Router Class Initialized
INFO - 2021-07-04 06:54:14 --> Router Class Initialized
INFO - 2021-07-04 06:54:14 --> Output Class Initialized
INFO - 2021-07-04 06:54:14 --> Security Class Initialized
DEBUG - 2021-07-04 06:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:54:14 --> Input Class Initialized
INFO - 2021-07-04 06:54:14 --> Language Class Initialized
ERROR - 2021-07-04 06:54:14 --> 404 Page Not Found: ../modules/laporan/controllers/Laporan/fetch_laporan_divisi
INFO - 2021-07-04 06:54:14 --> Output Class Initialized
INFO - 2021-07-04 06:54:14 --> Security Class Initialized
DEBUG - 2021-07-04 06:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:54:14 --> Input Class Initialized
INFO - 2021-07-04 06:54:14 --> Language Class Initialized
INFO - 2021-07-04 06:54:15 --> Language Class Initialized
INFO - 2021-07-04 06:54:15 --> Config Class Initialized
INFO - 2021-07-04 06:54:15 --> Loader Class Initialized
INFO - 2021-07-04 06:54:15 --> Helper loaded: url_helper
INFO - 2021-07-04 06:54:15 --> Helper loaded: file_helper
INFO - 2021-07-04 06:54:15 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:54:15 --> Database Driver Class Initialized
INFO - 2021-07-04 06:54:15 --> Email Class Initialized
INFO - 2021-07-04 06:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:54:15 --> Controller Class Initialized
DEBUG - 2021-07-04 06:54:15 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 06:54:15 --> Final output sent to browser
DEBUG - 2021-07-04 06:54:15 --> Total execution time: 0.2471
INFO - 2021-07-04 06:54:15 --> Config Class Initialized
INFO - 2021-07-04 06:54:15 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:54:15 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:54:15 --> Utf8 Class Initialized
INFO - 2021-07-04 06:54:15 --> URI Class Initialized
INFO - 2021-07-04 06:54:15 --> Router Class Initialized
INFO - 2021-07-04 06:54:15 --> Output Class Initialized
INFO - 2021-07-04 06:54:15 --> Security Class Initialized
DEBUG - 2021-07-04 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:54:15 --> Input Class Initialized
INFO - 2021-07-04 06:54:15 --> Language Class Initialized
ERROR - 2021-07-04 06:54:15 --> 404 Page Not Found: /index
INFO - 2021-07-04 06:59:10 --> Config Class Initialized
INFO - 2021-07-04 06:59:10 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:59:10 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:59:10 --> Utf8 Class Initialized
INFO - 2021-07-04 06:59:10 --> URI Class Initialized
INFO - 2021-07-04 06:59:10 --> Router Class Initialized
INFO - 2021-07-04 06:59:10 --> Output Class Initialized
INFO - 2021-07-04 06:59:10 --> Security Class Initialized
DEBUG - 2021-07-04 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:59:10 --> Input Class Initialized
INFO - 2021-07-04 06:59:10 --> Language Class Initialized
INFO - 2021-07-04 06:59:10 --> Language Class Initialized
INFO - 2021-07-04 06:59:10 --> Config Class Initialized
INFO - 2021-07-04 06:59:10 --> Loader Class Initialized
INFO - 2021-07-04 06:59:10 --> Helper loaded: url_helper
INFO - 2021-07-04 06:59:10 --> Helper loaded: file_helper
INFO - 2021-07-04 06:59:10 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:59:10 --> Database Driver Class Initialized
INFO - 2021-07-04 06:59:10 --> Email Class Initialized
INFO - 2021-07-04 06:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:59:10 --> Controller Class Initialized
DEBUG - 2021-07-04 06:59:10 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 06:59:10 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 06:59:10 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 06:59:10 --> Final output sent to browser
DEBUG - 2021-07-04 06:59:10 --> Total execution time: 0.0882
INFO - 2021-07-04 06:59:12 --> Config Class Initialized
INFO - 2021-07-04 06:59:12 --> Config Class Initialized
INFO - 2021-07-04 06:59:12 --> Hooks Class Initialized
INFO - 2021-07-04 06:59:12 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:59:12 --> Utf8 Class Initialized
INFO - 2021-07-04 06:59:12 --> URI Class Initialized
DEBUG - 2021-07-04 06:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:59:12 --> Router Class Initialized
INFO - 2021-07-04 06:59:12 --> Utf8 Class Initialized
INFO - 2021-07-04 06:59:12 --> Output Class Initialized
INFO - 2021-07-04 06:59:12 --> URI Class Initialized
INFO - 2021-07-04 06:59:12 --> Security Class Initialized
DEBUG - 2021-07-04 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:59:12 --> Input Class Initialized
INFO - 2021-07-04 06:59:12 --> Router Class Initialized
INFO - 2021-07-04 06:59:12 --> Language Class Initialized
INFO - 2021-07-04 06:59:12 --> Output Class Initialized
ERROR - 2021-07-04 06:59:12 --> 404 Page Not Found: ../modules/laporan/controllers/Laporan/fetch_laporan_divisi
INFO - 2021-07-04 06:59:12 --> Security Class Initialized
DEBUG - 2021-07-04 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:59:12 --> Input Class Initialized
INFO - 2021-07-04 06:59:12 --> Language Class Initialized
INFO - 2021-07-04 06:59:12 --> Language Class Initialized
INFO - 2021-07-04 06:59:12 --> Config Class Initialized
INFO - 2021-07-04 06:59:12 --> Loader Class Initialized
INFO - 2021-07-04 06:59:13 --> Helper loaded: url_helper
INFO - 2021-07-04 06:59:13 --> Helper loaded: file_helper
INFO - 2021-07-04 06:59:13 --> Helper loaded: develop_helper
INFO - 2021-07-04 06:59:13 --> Database Driver Class Initialized
INFO - 2021-07-04 06:59:13 --> Email Class Initialized
INFO - 2021-07-04 06:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 06:59:13 --> Controller Class Initialized
DEBUG - 2021-07-04 06:59:13 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 06:59:13 --> Final output sent to browser
DEBUG - 2021-07-04 06:59:13 --> Total execution time: 0.1362
INFO - 2021-07-04 06:59:13 --> Config Class Initialized
INFO - 2021-07-04 06:59:13 --> Hooks Class Initialized
DEBUG - 2021-07-04 06:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-04 06:59:13 --> Utf8 Class Initialized
INFO - 2021-07-04 06:59:13 --> URI Class Initialized
INFO - 2021-07-04 06:59:13 --> Router Class Initialized
INFO - 2021-07-04 06:59:13 --> Output Class Initialized
INFO - 2021-07-04 06:59:13 --> Security Class Initialized
DEBUG - 2021-07-04 06:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 06:59:13 --> Input Class Initialized
INFO - 2021-07-04 06:59:13 --> Language Class Initialized
ERROR - 2021-07-04 06:59:13 --> 404 Page Not Found: /index
INFO - 2021-07-04 07:01:47 --> Config Class Initialized
INFO - 2021-07-04 07:01:47 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:01:47 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:01:47 --> Utf8 Class Initialized
INFO - 2021-07-04 07:01:47 --> URI Class Initialized
INFO - 2021-07-04 07:01:47 --> Router Class Initialized
INFO - 2021-07-04 07:01:47 --> Output Class Initialized
INFO - 2021-07-04 07:01:47 --> Security Class Initialized
DEBUG - 2021-07-04 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:01:47 --> Input Class Initialized
INFO - 2021-07-04 07:01:47 --> Language Class Initialized
INFO - 2021-07-04 07:01:47 --> Language Class Initialized
INFO - 2021-07-04 07:01:47 --> Config Class Initialized
INFO - 2021-07-04 07:01:47 --> Loader Class Initialized
INFO - 2021-07-04 07:01:47 --> Helper loaded: url_helper
INFO - 2021-07-04 07:01:47 --> Helper loaded: file_helper
INFO - 2021-07-04 07:01:47 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:01:47 --> Database Driver Class Initialized
INFO - 2021-07-04 07:01:47 --> Email Class Initialized
INFO - 2021-07-04 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:01:47 --> Controller Class Initialized
DEBUG - 2021-07-04 07:01:47 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 07:01:47 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 07:01:47 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 07:01:47 --> Final output sent to browser
DEBUG - 2021-07-04 07:01:47 --> Total execution time: 0.1806
INFO - 2021-07-04 07:01:49 --> Config Class Initialized
INFO - 2021-07-04 07:01:49 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:01:49 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:01:49 --> Utf8 Class Initialized
INFO - 2021-07-04 07:01:49 --> URI Class Initialized
INFO - 2021-07-04 07:01:49 --> Router Class Initialized
INFO - 2021-07-04 07:01:49 --> Output Class Initialized
INFO - 2021-07-04 07:01:49 --> Security Class Initialized
DEBUG - 2021-07-04 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:01:49 --> Input Class Initialized
INFO - 2021-07-04 07:01:49 --> Language Class Initialized
INFO - 2021-07-04 07:01:49 --> Language Class Initialized
INFO - 2021-07-04 07:01:49 --> Config Class Initialized
INFO - 2021-07-04 07:01:49 --> Loader Class Initialized
INFO - 2021-07-04 07:01:49 --> Helper loaded: url_helper
INFO - 2021-07-04 07:01:49 --> Config Class Initialized
INFO - 2021-07-04 07:01:49 --> Hooks Class Initialized
INFO - 2021-07-04 07:01:49 --> Helper loaded: file_helper
INFO - 2021-07-04 07:01:49 --> Helper loaded: develop_helper
DEBUG - 2021-07-04 07:01:49 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:01:49 --> Utf8 Class Initialized
INFO - 2021-07-04 07:01:49 --> URI Class Initialized
INFO - 2021-07-04 07:01:49 --> Router Class Initialized
INFO - 2021-07-04 07:01:49 --> Output Class Initialized
INFO - 2021-07-04 07:01:49 --> Security Class Initialized
DEBUG - 2021-07-04 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:01:49 --> Input Class Initialized
INFO - 2021-07-04 07:01:49 --> Language Class Initialized
INFO - 2021-07-04 07:01:49 --> Language Class Initialized
INFO - 2021-07-04 07:01:49 --> Config Class Initialized
INFO - 2021-07-04 07:01:49 --> Loader Class Initialized
INFO - 2021-07-04 07:01:49 --> Helper loaded: url_helper
INFO - 2021-07-04 07:01:49 --> Database Driver Class Initialized
INFO - 2021-07-04 07:01:49 --> Email Class Initialized
INFO - 2021-07-04 07:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:01:49 --> Helper loaded: file_helper
INFO - 2021-07-04 07:01:49 --> Controller Class Initialized
INFO - 2021-07-04 07:01:49 --> Helper loaded: develop_helper
DEBUG - 2021-07-04 07:01:49 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 07:01:49 --> Final output sent to browser
DEBUG - 2021-07-04 07:01:49 --> Total execution time: 0.1570
INFO - 2021-07-04 07:01:49 --> Database Driver Class Initialized
INFO - 2021-07-04 07:01:49 --> Email Class Initialized
INFO - 2021-07-04 07:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:01:49 --> Controller Class Initialized
DEBUG - 2021-07-04 07:01:49 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 07:01:49 --> Final output sent to browser
DEBUG - 2021-07-04 07:01:49 --> Total execution time: 0.1249
INFO - 2021-07-04 07:01:50 --> Config Class Initialized
INFO - 2021-07-04 07:01:50 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:01:50 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:01:50 --> Utf8 Class Initialized
INFO - 2021-07-04 07:01:50 --> URI Class Initialized
INFO - 2021-07-04 07:01:50 --> Router Class Initialized
INFO - 2021-07-04 07:01:50 --> Output Class Initialized
INFO - 2021-07-04 07:01:50 --> Security Class Initialized
DEBUG - 2021-07-04 07:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:01:50 --> Input Class Initialized
INFO - 2021-07-04 07:01:50 --> Language Class Initialized
ERROR - 2021-07-04 07:01:50 --> 404 Page Not Found: /index
INFO - 2021-07-04 07:02:03 --> Config Class Initialized
INFO - 2021-07-04 07:02:03 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:03 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:03 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:03 --> URI Class Initialized
INFO - 2021-07-04 07:02:03 --> Router Class Initialized
INFO - 2021-07-04 07:02:03 --> Output Class Initialized
INFO - 2021-07-04 07:02:03 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:03 --> Input Class Initialized
INFO - 2021-07-04 07:02:03 --> Language Class Initialized
INFO - 2021-07-04 07:02:03 --> Language Class Initialized
INFO - 2021-07-04 07:02:03 --> Config Class Initialized
INFO - 2021-07-04 07:02:03 --> Loader Class Initialized
INFO - 2021-07-04 07:02:03 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:03 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:03 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:02:03 --> Database Driver Class Initialized
INFO - 2021-07-04 07:02:03 --> Email Class Initialized
INFO - 2021-07-04 07:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:03 --> Controller Class Initialized
DEBUG - 2021-07-04 07:02:03 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 07:02:03 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 07:02:03 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 07:02:03 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:03 --> Total execution time: 0.0952
INFO - 2021-07-04 07:02:05 --> Config Class Initialized
INFO - 2021-07-04 07:02:05 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:05 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:05 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:05 --> URI Class Initialized
INFO - 2021-07-04 07:02:05 --> Router Class Initialized
INFO - 2021-07-04 07:02:05 --> Config Class Initialized
INFO - 2021-07-04 07:02:05 --> Hooks Class Initialized
INFO - 2021-07-04 07:02:05 --> Output Class Initialized
INFO - 2021-07-04 07:02:05 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:05 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:05 --> Utf8 Class Initialized
DEBUG - 2021-07-04 07:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:05 --> URI Class Initialized
INFO - 2021-07-04 07:02:05 --> Input Class Initialized
INFO - 2021-07-04 07:02:05 --> Language Class Initialized
INFO - 2021-07-04 07:02:05 --> Router Class Initialized
INFO - 2021-07-04 07:02:05 --> Output Class Initialized
INFO - 2021-07-04 07:02:05 --> Language Class Initialized
INFO - 2021-07-04 07:02:05 --> Config Class Initialized
INFO - 2021-07-04 07:02:05 --> Loader Class Initialized
INFO - 2021-07-04 07:02:05 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:05 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:05 --> Security Class Initialized
INFO - 2021-07-04 07:02:05 --> Helper loaded: develop_helper
DEBUG - 2021-07-04 07:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:05 --> Input Class Initialized
INFO - 2021-07-04 07:02:05 --> Language Class Initialized
INFO - 2021-07-04 07:02:05 --> Database Driver Class Initialized
INFO - 2021-07-04 07:02:05 --> Language Class Initialized
INFO - 2021-07-04 07:02:05 --> Config Class Initialized
INFO - 2021-07-04 07:02:05 --> Loader Class Initialized
INFO - 2021-07-04 07:02:05 --> Email Class Initialized
INFO - 2021-07-04 07:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:05 --> Controller Class Initialized
DEBUG - 2021-07-04 07:02:05 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 07:02:05 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:05 --> Total execution time: 0.0996
INFO - 2021-07-04 07:02:05 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:05 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:05 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:02:05 --> Database Driver Class Initialized
INFO - 2021-07-04 07:02:06 --> Email Class Initialized
INFO - 2021-07-04 07:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:06 --> Controller Class Initialized
DEBUG - 2021-07-04 07:02:06 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 07:02:06 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:06 --> Total execution time: 0.1658
INFO - 2021-07-04 07:02:06 --> Config Class Initialized
INFO - 2021-07-04 07:02:06 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:06 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:06 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:06 --> URI Class Initialized
INFO - 2021-07-04 07:02:06 --> Router Class Initialized
INFO - 2021-07-04 07:02:06 --> Output Class Initialized
INFO - 2021-07-04 07:02:06 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:06 --> Input Class Initialized
INFO - 2021-07-04 07:02:06 --> Language Class Initialized
ERROR - 2021-07-04 07:02:06 --> 404 Page Not Found: /index
INFO - 2021-07-04 07:02:20 --> Config Class Initialized
INFO - 2021-07-04 07:02:20 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:20 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:20 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:20 --> URI Class Initialized
INFO - 2021-07-04 07:02:20 --> Router Class Initialized
INFO - 2021-07-04 07:02:20 --> Output Class Initialized
INFO - 2021-07-04 07:02:20 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:20 --> Input Class Initialized
INFO - 2021-07-04 07:02:20 --> Language Class Initialized
INFO - 2021-07-04 07:02:20 --> Language Class Initialized
INFO - 2021-07-04 07:02:20 --> Config Class Initialized
INFO - 2021-07-04 07:02:20 --> Loader Class Initialized
INFO - 2021-07-04 07:02:20 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:20 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:20 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:02:20 --> Database Driver Class Initialized
INFO - 2021-07-04 07:02:20 --> Email Class Initialized
INFO - 2021-07-04 07:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:20 --> Controller Class Initialized
DEBUG - 2021-07-04 07:02:20 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
DEBUG - 2021-07-04 07:02:20 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/views/laporan_view.php
DEBUG - 2021-07-04 07:02:20 --> File loaded: C:\xampp\htdocs\esi\application\views\template_view.php
INFO - 2021-07-04 07:02:20 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:20 --> Total execution time: 0.1173
INFO - 2021-07-04 07:02:21 --> Config Class Initialized
INFO - 2021-07-04 07:02:21 --> Hooks Class Initialized
INFO - 2021-07-04 07:02:21 --> Config Class Initialized
INFO - 2021-07-04 07:02:21 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:21 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:21 --> Utf8 Class Initialized
DEBUG - 2021-07-04 07:02:21 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:21 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:21 --> URI Class Initialized
INFO - 2021-07-04 07:02:21 --> URI Class Initialized
INFO - 2021-07-04 07:02:21 --> Router Class Initialized
INFO - 2021-07-04 07:02:21 --> Router Class Initialized
INFO - 2021-07-04 07:02:21 --> Output Class Initialized
INFO - 2021-07-04 07:02:21 --> Output Class Initialized
INFO - 2021-07-04 07:02:21 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:21 --> Input Class Initialized
INFO - 2021-07-04 07:02:21 --> Language Class Initialized
INFO - 2021-07-04 07:02:21 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:21 --> Input Class Initialized
INFO - 2021-07-04 07:02:21 --> Language Class Initialized
INFO - 2021-07-04 07:02:21 --> Language Class Initialized
INFO - 2021-07-04 07:02:21 --> Config Class Initialized
INFO - 2021-07-04 07:02:21 --> Loader Class Initialized
INFO - 2021-07-04 07:02:21 --> Language Class Initialized
INFO - 2021-07-04 07:02:21 --> Config Class Initialized
INFO - 2021-07-04 07:02:21 --> Loader Class Initialized
INFO - 2021-07-04 07:02:21 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:21 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:21 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:02:21 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:21 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:21 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:02:21 --> Database Driver Class Initialized
INFO - 2021-07-04 07:02:21 --> Email Class Initialized
INFO - 2021-07-04 07:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:21 --> Controller Class Initialized
INFO - 2021-07-04 07:02:21 --> Database Driver Class Initialized
DEBUG - 2021-07-04 07:02:21 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 07:02:21 --> Email Class Initialized
INFO - 2021-07-04 07:02:21 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:21 --> Total execution time: 0.1665
INFO - 2021-07-04 07:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:21 --> Controller Class Initialized
DEBUG - 2021-07-04 07:02:21 --> File loaded: C:\xampp\htdocs\esi\application\modules/laporan/models/M_laporan.php
INFO - 2021-07-04 07:02:21 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:21 --> Total execution time: 0.1784
INFO - 2021-07-04 07:02:23 --> Config Class Initialized
INFO - 2021-07-04 07:02:23 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:23 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:23 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:23 --> URI Class Initialized
INFO - 2021-07-04 07:02:23 --> Router Class Initialized
INFO - 2021-07-04 07:02:23 --> Output Class Initialized
INFO - 2021-07-04 07:02:23 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:23 --> Input Class Initialized
INFO - 2021-07-04 07:02:23 --> Language Class Initialized
ERROR - 2021-07-04 07:02:23 --> 404 Page Not Found: /index
INFO - 2021-07-04 07:02:24 --> Config Class Initialized
INFO - 2021-07-04 07:02:24 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:24 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:24 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:24 --> URI Class Initialized
INFO - 2021-07-04 07:02:24 --> Router Class Initialized
INFO - 2021-07-04 07:02:24 --> Output Class Initialized
INFO - 2021-07-04 07:02:24 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:24 --> Input Class Initialized
INFO - 2021-07-04 07:02:24 --> Language Class Initialized
INFO - 2021-07-04 07:02:24 --> Language Class Initialized
INFO - 2021-07-04 07:02:24 --> Config Class Initialized
INFO - 2021-07-04 07:02:24 --> Loader Class Initialized
INFO - 2021-07-04 07:02:24 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:24 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:24 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:02:24 --> Database Driver Class Initialized
INFO - 2021-07-04 07:02:24 --> Email Class Initialized
INFO - 2021-07-04 07:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:24 --> Controller Class Initialized
DEBUG - 2021-07-04 07:02:24 --> File loaded: C:\xampp\htdocs\esi\application\modules/login/models/M_login.php
INFO - 2021-07-04 07:02:24 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:24 --> Total execution time: 0.1536
INFO - 2021-07-04 07:02:35 --> Config Class Initialized
INFO - 2021-07-04 07:02:35 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:35 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:35 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:35 --> URI Class Initialized
INFO - 2021-07-04 07:02:35 --> Router Class Initialized
INFO - 2021-07-04 07:02:35 --> Output Class Initialized
INFO - 2021-07-04 07:02:35 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:35 --> Input Class Initialized
INFO - 2021-07-04 07:02:35 --> Language Class Initialized
INFO - 2021-07-04 07:02:35 --> Language Class Initialized
INFO - 2021-07-04 07:02:35 --> Config Class Initialized
INFO - 2021-07-04 07:02:35 --> Loader Class Initialized
INFO - 2021-07-04 07:02:35 --> Helper loaded: url_helper
INFO - 2021-07-04 07:02:35 --> Helper loaded: file_helper
INFO - 2021-07-04 07:02:35 --> Helper loaded: develop_helper
INFO - 2021-07-04 07:02:35 --> Database Driver Class Initialized
INFO - 2021-07-04 07:02:35 --> Email Class Initialized
INFO - 2021-07-04 07:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-04 07:02:35 --> Controller Class Initialized
DEBUG - 2021-07-04 07:02:35 --> File loaded: C:\xampp\htdocs\esi\application\modules/login/models/M_login.php
DEBUG - 2021-07-04 07:02:35 --> File loaded: C:\xampp\htdocs\esi\application\modules/login/views/login_view.php
INFO - 2021-07-04 07:02:35 --> Final output sent to browser
DEBUG - 2021-07-04 07:02:35 --> Total execution time: 0.1325
INFO - 2021-07-04 07:02:36 --> Config Class Initialized
INFO - 2021-07-04 07:02:36 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:36 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:36 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:36 --> Config Class Initialized
INFO - 2021-07-04 07:02:36 --> URI Class Initialized
INFO - 2021-07-04 07:02:36 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:36 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:36 --> Router Class Initialized
INFO - 2021-07-04 07:02:36 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:36 --> URI Class Initialized
INFO - 2021-07-04 07:02:36 --> Output Class Initialized
INFO - 2021-07-04 07:02:36 --> Security Class Initialized
INFO - 2021-07-04 07:02:36 --> Router Class Initialized
DEBUG - 2021-07-04 07:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:36 --> Input Class Initialized
INFO - 2021-07-04 07:02:36 --> Language Class Initialized
INFO - 2021-07-04 07:02:36 --> Output Class Initialized
ERROR - 2021-07-04 07:02:36 --> 404 Page Not Found: /index
INFO - 2021-07-04 07:02:36 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:36 --> Input Class Initialized
INFO - 2021-07-04 07:02:36 --> Language Class Initialized
ERROR - 2021-07-04 07:02:36 --> 404 Page Not Found: /index
INFO - 2021-07-04 07:02:36 --> Config Class Initialized
INFO - 2021-07-04 07:02:36 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:36 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:36 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:36 --> URI Class Initialized
INFO - 2021-07-04 07:02:36 --> Router Class Initialized
INFO - 2021-07-04 07:02:36 --> Output Class Initialized
INFO - 2021-07-04 07:02:36 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:36 --> Input Class Initialized
INFO - 2021-07-04 07:02:36 --> Language Class Initialized
ERROR - 2021-07-04 07:02:36 --> 404 Page Not Found: /index
INFO - 2021-07-04 07:02:38 --> Config Class Initialized
INFO - 2021-07-04 07:02:38 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:02:38 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:02:38 --> Utf8 Class Initialized
INFO - 2021-07-04 07:02:38 --> URI Class Initialized
INFO - 2021-07-04 07:02:38 --> Router Class Initialized
INFO - 2021-07-04 07:02:38 --> Output Class Initialized
INFO - 2021-07-04 07:02:38 --> Security Class Initialized
DEBUG - 2021-07-04 07:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:02:38 --> Input Class Initialized
INFO - 2021-07-04 07:02:38 --> Language Class Initialized
ERROR - 2021-07-04 07:02:38 --> 404 Page Not Found: /index
